package ssoext;

import java.lang.Object;
import java.util.*;
import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.web.util.HtmlUtils;

import java.net.URLDecoder;
import java.text.DecimalFormat;

@SuppressWarnings("unchecked")
/**
 *
 * Provides methods for text related conversions
 * Also provides some html formatting helper methods
 *
 */

public class texthelp
{

	/**
	 * Default constructor for texthelp class
	 */
	public texthelp()
	{
	}

	public static final String specialCharsNames = "`~!@#$%^&*()+|}{\":?><,./;'[]\\=";

	public static final String specialCharsUserNames = "`~!@#$%^&*()+|}{\":?><,./;'[]\\=-";

	private static final String specialCharsEmail = "!\"#$%&(),:;<>,[\\]|/";

	public static final String specialCharsAll = "`~!@#$%^&*()+|}{\":?><,./;'[]\\=-_";


	/**
	 * Return if a String is numeric or not
	 *
	 * @param s (String):  the String
	 * @return boolean -  if numeric
	 */
	public static boolean isNumeric(String s)
	{
		return isNumericSpecialDecimalChar(s, ".");
	} // end isNumeric

	/**
	 * Return if a String is numeric or not, relative to special number formatting
	 *
	 * @param s (String):  the String
	 * @return boolean -  if numeric
	 */
	public static boolean isNumericSpecialDecimalChar(String s, String decimalchar)
	{

		if (decimalchar.equals(""))
			decimalchar = ".";

		boolean ret = true;
		if (s.equals("") || s.equals("-") || s.equals(".") || s.equals("-.") || s.equals(".-"))
			ret = false;
		else
		{
			Vector<String> numerics = new Vector<String>();
			for (int i = 0; i <= 9; i++)
			{
				numerics.add(String.valueOf(i));
			}
			numerics.add(decimalchar);
			numerics.add("-");
			for (int i = 0; i < s.length(); i++)
			{
				String sub = s.substring(i, i + 1);
				if (!numerics.contains(sub))
				{
					ret = false;
					break;
				}
			}

			// dash in the middle..
			if (ret && s.indexOf("-") > -1)
			{
				if (!s.startsWith("-"))
					ret = false;

				String checkrest = s.substring(1);
				if (checkrest.indexOf("-") > -1)
					ret = false;
			}

			// multiple decimal seperators..
			int countDecimals = 0;
			for (int i = 0; i < s.length(); i++)
			{
				String sub = s.substring(i, i + 1);
				if (sub.equals(decimalchar))
					countDecimals++;
			}

			if (countDecimals>1)
				ret = false;


		}
		return ret;
	} // end isNumericSpecialDecimalChar

	/**
	 * Return the format the input datasets require
	 *
	 * @param theDate (String):  Date in ISO
	 * @return String - the newly formatted date
	 */
	public static String getRunDataSetDateFormatFromSQLFormat(String theDate)
	{

		String ret = "";
		if (!theDate.equals("")) {

			String theMonth = getField (theDate, "-", 2);
			String theDay = getField (theDate, "-", 3);
			String theYear = getField(theDate, "-", 1);

			if (!theMonth.equals("") && isOnlyNumbers(theMonth)
				&& !theYear.equals("") && isOnlyNumbers(theYear)
				&& !theDay.equals("") && isOnlyNumbers(theDay)
				) {
				int theMonthInt = Integer.valueOf(theMonth).intValue();
				int theDayInt = Integer.valueOf(theDay).intValue();

				ret = String.valueOf(theMonthInt)+"/"+String.valueOf(theDayInt) + "/" + theYear;
			}

			//ret = theDate; // ISO.. would need non-proc import?

		}

		return ret;
	}


	/**
	 * Return the format the input datasets require (reverse.. back to ISO
	 *
	 * @param theDate (String):  Date in Run Data set format.. i.e. what getRunDataSetDateFormatFromSQLFormat produces..
	 * @return String - the ISO formatted date
	 */
	public static String getSQLFormatFromRunDataSetDateFormat(String theDate)
	{

		String ret = "";
		if (!theDate.equals("")) {

			String theMonth = getField (theDate, "/", 1);
			String theDay = getField (theDate, "/", 2);
			String theYear = getField (theDate, "/", 3);

			if (theMonth.length()==1)
				theMonth = "0"+theMonth;
			if (theDay.length()==1)
				theDay = "0"+theDay;

			ret = theYear+"-"+theMonth + "-" + theDay;

		}

		return ret;
	}

	/**
	 * When RANGE= in the rule for classes.. check the value against the range.. return empty if no issues
	 *
	 * @param ruleFromClasses (String):  from classes
	 * @param theValue (String):  text
	 * @return String - empty if no issues, otherwise the error message is returend
	 */
	public static String getErrorMessageOnRange(String ruleFromClasses, String thisSubmit, String errorMessageStart)
	{
		String ret = "";

		String thisLow = "";
		String thisHigh = "";
		Vector rulesSplit = texthelp.explode (ruleFromClasses, "~");
		for (int j=0; j<rulesSplit.size(); j++) {
			String thisJ = (String)rulesSplit.get(j);
			String thisJ_Name = texthelp.getField (thisJ, "=", 1);
			if (thisJ_Name.equals("RANGE")) {
				String theRange = texthelp.getField (thisJ, "=", 2);
				thisLow = texthelp.getField (theRange, ",", 1);
				thisHigh = texthelp.getField (theRange, ",", 2);
				break;
			}
		}

		if (thisLow.equals("") || thisHigh.equals("") || !texthelp.isNumeric(thisLow) || !texthelp.isNumeric(thisHigh) ) {
			ret = errorMessageStart+" problem with range defintion on this field, contact adminstrator.";
		}
		else {

			if (ruleFromClasses.indexOf("FLOAT")>-1 || ruleFromClasses.indexOf("PERCENT")>-1) {
				float thisLowFloat = Float.valueOf(thisLow).floatValue();
				float thisHighFloat = Float.valueOf(thisHigh).floatValue();
				if (texthelp.isNumeric(thisSubmit) && !thisSubmit.equals("")) {
					float thisSubmitFloat = Float.valueOf(thisSubmit).floatValue();
					if (thisLowFloat>thisSubmitFloat || thisHighFloat<thisSubmitFloat) {
						ret = errorMessageStart+" out of range "+thisLow+" - "+thisHigh+".";
					}
				}
			}
			else if (ruleFromClasses.indexOf("NUMERIC")>-1) {
				int thisLowInt = Integer.valueOf(thisLow).intValue();
				int thisHighInt = Integer.valueOf(thisHigh).intValue();
				if (texthelp.isOnlyNumbers(thisSubmit) && !thisSubmit.equals("")) {
					int thisSubmitInt = Integer.valueOf(thisSubmit).intValue();
					if (thisLowInt>thisSubmitInt || thisHighInt<thisSubmitInt) {
						ret = errorMessageStart+" out of range "+thisLow+" - "+thisHigh+".";
					}
				}
			}
		}

		return ret;
	} // end getErrorMessageOnRange


	/**
	 * Return choices list - like classes return from a non-empty override to the algorithm choices.   (from area settings)
	 *
	 * @param theOverride (String):  the saved area setting
	 *
	 * @return Vector of Vectors - ordered like return of getClassesFull
	 */
	public static Vector getLROAlgoChoicesAsClassesVector(String theOverride) {

		Vector ret = new Vector();

		Vector expIt = texthelp.explode(theOverride, "^^^");
		for (int j=0; j<expIt.size(); j++) {
			String thisID = (String)expIt.get(j);
			if (!thisID.equals("")) {

				// Stored as ^^^ delim.. then   Visual ID===Label===Internal Engine ID===Min Baskets===Max Baskets===Static Basket Country list (comma delim for in basket, / delim for baskets)

				String theInternalID = texthelp.getField(thisID, "===", 3);
				if (theInternalID.equals(""))  // for backword compatible
					theInternalID = texthelp.getField(thisID, "===", 1);

				String theRuleLikeClasses = "ID="+theInternalID;

				String minb = texthelp.getField(thisID, "===", 4);
				if (!minb.equals(""))
					theRuleLikeClasses += "~MINBASKETS="+minb;

				String maxb = texthelp.getField(thisID, "===", 5);
				if (!maxb.equals(""))
					theRuleLikeClasses += "~MAXBASKETS="+maxb;

				String staticb = texthelp.getField(thisID, "===", 6);
				if (!staticb.equals(""))
					theRuleLikeClasses += "~STATICBASKETS="+staticb;


				ret.add (texthelp.getVectorForItems (
						theInternalID,
						"",
						"",
						texthelp.getField(thisID, "===", 1),
						texthelp.getField(thisID, "===", 2),
						"",
						"",
						"",
						theRuleLikeClasses,
						""
						));

						// here showing ID / ID (same '1' above twice) ... default is classID/visual ID.. override is ID = Visual ID
			}
		}


		return ret;

	} // end getLROAlgoChoicesAsClassesVector


	/**
	 * Return rule values from the classes rule for a pricing rule (Min, Max, Static)
	 *
	 * @param theRuleVal (String):  the value from classes table (getCLasesFull 8th spot or 8th spot of getLROAlgoChoicesAsClassesVector)
	 *
	 * @return String Min~Max~StaticBaskets
	 */
	public static String getLROPricingRuleRules(String theRuleVal) {

		String ret = "";

		String thisMin = "";
		String thisMax = "";
		String thisStatic = "";

		Vector expRules = texthelp.explode(theRuleVal, "~");
		for (int r=0; r<expRules.size(); r++) {
			String thisR = (String)expRules.get(r);
			String thisRName = texthelp.getField (thisR, "=", 1);
			if (thisRName.equals("MINBASKETS"))
				thisMin = texthelp.getField (thisR, "=", 2);
			else if (thisRName.equals("MAXBASKETS"))
				thisMax = texthelp.getField (thisR, "=", 2);
			else if (thisRName.equals("STATICBASKETS"))
				thisStatic = texthelp.getField (thisR, "=", 2);
		}

		ret = thisMin+"~"+thisMax+"~"+thisStatic;


		return ret;

	} // end getLROPricingRuleRules


	/**
	 * Return any errors with a country's ref basket versus pricing rule strings.
	 *
	 * @param refbasketVal (String):  The raw value saved for ref baskets.. would have country IDs in it
	 * @param theRuleVal (String):  the value from classes table (getCLasesFull 8th spot or 8th spot of getLROAlgoChoicesAsClassesVector)
	 * @param allcountries (Vector):  from getLROCountries, needed if there is a STATICBASKETS rule
	 * @param isLaunch (String):  if should check launch rule or reference rule
	 *
	 * @return String empty if no issues, otherwise the ERROR: ..  to display to screen
	 */
	public static String getLROErrorsForPricingRule(String countryPrint, String refbasketVal, String theRuleVal, Vector allcountries, boolean isLaunch) {

		String ret = "";

		String theRuleSet = getLROPricingRuleRules(theRuleVal);

		String min = texthelp.getField(theRuleSet, "~", 1);
		String staticval = texthelp.getField(theRuleSet, "~", 3);

		int countBaskets = 0;
		if (!refbasketVal.equals("")) {
			Vector baskets = texthelp.explode(refbasketVal, ":");
			countBaskets = baskets.size();
		}
		
		String launchText = "";
		if (isLaunch)
			launchText = "launch ";

		boolean staticError = false;

		if (!staticval.equals("")) {

			Vector staticbaskets = texthelp.explode(staticval, "/");

			for (int i=0; i<staticbaskets.size(); i++) {
				String thisSList = (String)staticbaskets.get(i);
				Vector staticList = texthelp.explode(thisSList, ",", true);

				String listFromVal = texthelp.getField (refbasketVal, ":", (i+1));
				Vector expList = texthelp.explode(listFromVal, "^");

				Vector currList = new Vector();
				for (int j=0; j<expList.size(); j++) {
					String thisJ = (String)expList.get(j);
					if (!thisJ.equals("")) {
						String thisAbbrev = texthelp.getMatchingAll_ReturnIndexVal (allcountries, thisJ, 0, 13);
						if (thisAbbrev.equals("")) // problem with the list of all?
							thisAbbrev = "?";
						currList.add(thisAbbrev);
					}
				}

				staticList = texthelp.sortStringVector (staticList, true);
				currList = texthelp.sortStringVector (currList, true);

				if (!staticList.equals(currList)) {
					staticError = true;
					ret += "ERROR: "+countryPrint+" has a "+launchText+"pricing rule / reference baskets conflict.  The current rule must have a specific basket for basket #"+(i+1)+".      Current Basket = "+currList+" / Expected Basket = "+staticList;
				}

			}
		}

		if (!staticError) {
			if (!min.equals("")) {
				int minInt = Integer.valueOf(min).intValue();
				if (countBaskets<minInt) {
					if (minInt==0)
						ret += "ERROR: "+countryPrint+" has a "+launchText+"pricing rule / reference baskets conflict.  The current rule must must not have any reference baskets set.";
					else
						ret += "ERROR: "+countryPrint+" has a "+launchText+"pricing rule / reference baskets conflict.  The current rule must have at least "+minInt+" reference basket(s).";
				}
			}
			//LROPT-440 - allow to chose a rule LESS than the number of reference baskets you have currently
			/*
			if (!max.equals("")) {
				int maxInt = Integer.valueOf(max).intValue();
				if (countBaskets>maxInt)
					ret += "ERROR: "+countryPrint+" has a "+launchText+"reference rule / reference baskets conflict.  The current rule can have at most "+maxInt+" reference basket(s).";
			}
			*/
		}



		return ret;

	} // end getLROErrorsForPricingRule


	/**
	 * Return choice list for quarterly choices
	 *
	 * @param choiceStart (String):  format is 'year QX'
	 * @param numChoices (int):  the number of choices
	 *
	 * @return Vector of Strings - includes empty at start.. the choices from the choiceStart, and numChoices many choices
	 */
	public static Vector getLROQuarterlyChoices(String choiceStart, int numChoices) {

		Vector ret = new Vector();

		ret.add("");

		String lastDateCycle = choiceStart;
		ret.add(choiceStart);

		for (int i=1; i<numChoices; i++) {
			// add a quarter
			String theYear = texthelp.getField (lastDateCycle, " ", 1);
			String theQPart = texthelp.getField (lastDateCycle, " ", 2);

			if (isOnlyNumbers(theYear)) {

				boolean doAdd = true;

				String theNextOne = "";
				if (theQPart.equals("Q4")) {
					int theYearInt = Integer.valueOf(theYear).intValue();
					theNextOne = String.valueOf(theYearInt+1) + " Q1";
				}
				else if (theQPart.equals("Q1")) {
					theNextOne = theYear + " Q2";
				}
				else if (theQPart.equals("Q2")) {
					theNextOne = theYear + " Q3";
				}
				else if (theQPart.equals("Q3")) {
					theNextOne = theYear + " Q4";
				}
				else  {
					doAdd = false;
				}

				if (doAdd) {
					ret.add(theNextOne);
					lastDateCycle = theNextOne;
				}
			}

		}
		return ret;

	}

	/**
	 * Return Return rows in the view for country event details., i.e. the why page on price changes
	 *
	 * @param resFileContents (Vector of Strings):  path to the res file.. FILTERED to the country in question (or other rows)
	 * @param country (String):  the country looking for
	 * @param mappingsDate (Vector of Vectors):  date mappings.. i.e for quarterly
	 * @param SESSdatecontrolformat (String):  the format to return dates as
	 *
	 * @return Vector of Vectors
	 * 0 = Date
	 * 1 = Event Type
	 * 2 = Rule
	 * 3 = Price
	 * 4 = Vector of Vectors.. country abbrev, country price
	 */
	public static Vector getCountryEventDetailsFromResFile(Vector resFileContents, Vector mappingsDate, String SESSdatecontrolformat,
			String currIntervalChoice, boolean doDateFormatting, String textForRule, String pathToRes, String countryAbbrev) {

		Vector ret = new Vector();

		datehelp myDate = new datehelp();

		//0="SRC_CNTY_ID",
		//1="tr_cnty_id",
		//2="date",
		//3="event",
		//4="src_price",
		//5="trt_price",
		//6="algoName"

		Vector datesWithEvents = new Vector();  // lines that are the main describer of the event, date, type, country source price, and ALGO rule
		Vector datesAdded = new Vector();
		for (int i=0; i<resFileContents.size(); i++) {
			Vector thisV = (Vector)resFileContents.get(i);
			String thisDate = (String)thisV.get(2);
			String thisEvent = (String)thisV.get(3);
			if (!datesAdded.contains(thisDate)) {


				if (thisEvent.equals("None")) {

					//if (datesWithEvents.size()>0) // this will allow this date to add.. i.e. the first.. as long as dataset is sorted!!?
					// don't use the first date as launch.. its actually not.. and will need to get from the waterfall.dat files

						continue;
				}

				datesWithEvents.add(thisV);
				datesAdded.add(thisDate);
			}
		}

		for (int i=0; i<datesWithEvents.size(); i++) {
			Vector thisV = (Vector)datesWithEvents.get(i);
			String thisDate = (String)thisV.get(2);
			String thisType = (String)thisV.get(3);
			String thisRule = (String)thisV.get(6);
			String thisPrice = texthelp.getFloatDisplayFormatted((String)thisV.get(4), 2);

			Vector refs = new Vector();  // country abbrev, country name, price
			for (int j=0; j<resFileContents.size(); j++) {
				Vector thisJ = (Vector)resFileContents.get(j);
				String thisDateJ = (String)thisJ.get(2);
				if (thisDate.equals(thisDateJ)) {
					String thisTargetCountry = (String)thisJ.get(1);
					if (!thisTargetCountry.equals("")) {
						refs.add (texthelp.getVectorForItems (thisTargetCountry, texthelp.getFloatDisplayFormatted((String)thisJ.get(5), 2), ""));
					}
				}
			}


			refs = texthelp.sortVectorStringsOneIndex (refs, 1, false);

			// based on the ruletype.. some graying on it..
			if (refs.size()>0) {

				if (textForRule.indexOf("Second lowest of reference basket")>-1) {
					if (refs.size()>1) {
						Vector theOne = (Vector)refs.get(refs.size()-2);
						String theMatchingPrice = (String)theOne.get(1);
						for (int r=0; r<refs.size(); r++) {
							Vector theChange = (Vector)refs.get(r);
							String thisPriceR = (String)theChange.get(1);
							if (r!=(refs.size()-2) && !thisPriceR.equals(theMatchingPrice)) {
								// gray all but the 2nd to last
								theChange.setElementAt("GRAY", 2);
								refs.setElementAt(theChange, r);
							}
						}
					}
				}
				else if (textForRule.indexOf("Third lowest of reference basket")>-1) {
					if (refs.size()>2) {
						Vector theOne = (Vector)refs.get(refs.size()-3);
						String theMatchingPrice = (String)theOne.get(1);
						for (int r=0; r<refs.size(); r++) {
							Vector theChange = (Vector)refs.get(r);
							String thisPriceR = (String)theChange.get(1);
							if (r!=(refs.size()-3) && !thisPriceR.equals(theMatchingPrice)) {
								// gray all but the 2nd to last
								theChange.setElementAt("GRAY", 2);
								refs.setElementAt(theChange, r);
							}
						}
					}
				}
				else if (textForRule.indexOf("Average of five lowest in reference basket")>-1) {
					if (refs.size()>5) {
						for (int r=0; r<refs.size(); r++) {
							if (r<(refs.size()-5)) {
								// gray all but the 2nd to last
								Vector theChange = (Vector)refs.get(r);
								theChange.setElementAt("GRAY", 2);
								refs.setElementAt(theChange, r);
							}
						}
					}
				}
				else if (textForRule.indexOf("3 lowest")>-1 || textForRule.indexOf("three lowest")>-1) {
					if (refs.size()>3) {
						for (int r=0; r<refs.size(); r++) {
							if (r<(refs.size()-3)) {
								// gray all but the 2nd to last
								Vector theChange = (Vector)refs.get(r);
								theChange.setElementAt("GRAY", 2);
								refs.setElementAt(theChange, r);
							}
						}
					}
				}
				else if (textForRule.indexOf("Lowest of reference basket")>-1 || textForRule.indexOf("times lowest of reference basket")>-1) {
					if (refs.size()>1) {

						Vector theOne = (Vector)refs.get(refs.size()-1);
						String theMatchingPrice = (String)theOne.get(1);

						for (int r=0; r<refs.size(); r++) {
							Vector theChange = (Vector)refs.get(r);
							String thisPriceR = (String)theChange.get(1);
							if (r!=(refs.size()-1)  && !thisPriceR.equals(theMatchingPrice)) {
								// gray all but the 2nd to last
								theChange.setElementAt("GRAY", 2);
								refs.setElementAt(theChange, r);
							}
						}
					}
				}
				else if (textForRule.indexOf("Second maximum of reference basket")>-1) {
					if (refs.size()>1) {

						Vector theOne = (Vector)refs.get(1);
						String theMatchingPrice = (String)theOne.get(1);

						for (int r=0; r<refs.size(); r++) {
							Vector theChange = (Vector)refs.get(r);
							String thisPriceR = (String)theChange.get(1);
							if (r!=(1)  && !thisPriceR.equals(theMatchingPrice)) {
								// gray all but the 2nd to last
								theChange.setElementAt("GRAY", 2);
								refs.setElementAt(theChange, r);
							}
						}
					}
				}
			}


			thisDate = myDate.getSQLFormatFromResultsDateFormat(thisDate);

			if (doDateFormatting) {

				if (currIntervalChoice.equals("Quarterly"))
					thisDate = texthelp.getMatchingAll_ReturnIndexVal (mappingsDate, thisDate, 1, 0);
				else
					thisDate = myDate.getShortDate (thisDate, SESSdatecontrolformat);
			}

			Vector thisAdd = new Vector();
			thisAdd.add (thisDate);
			//if (thisType.equals("None") && ret.size()==0)
			//	thisType = "Launch";
			thisAdd.add (thisType);
			thisAdd.add (thisRule);
			thisAdd.add (thisPrice);
			thisAdd.add (refs);

			ret.add (thisAdd);

		}

		// look for launch .. if not there.. its missing from res?  (issue with countries with no launch in basket and the optimal DS??
		boolean foundLaunch = false;
		for (int i=0; i<ret.size(); i++) {
			Vector thisV = (Vector)ret.get(i);
			String thisType = (String)thisV.get(1);
			if (thisType.equals("Launch")) {
				foundLaunch = true;
				break;
			}
		}

		if (!foundLaunch) {

			if (!pathToRes.endsWith("/"))
				pathToRes += "/";

			// need to get from waterfall.dat
			if (filehelp.checkFile (pathToRes+"waterfall.dat")) {

				Vector waterfallfile = filehelp.getFileContentsToVector (pathToRes+"waterfall.dat");
				if (waterfallfile.size()>0) {
					String headerLine = (String)waterfallfile.get(0);

					for (int i=1; i<waterfallfile.size(); i++) {
						String thisLine = (String)waterfallfile.get(i);
						String thisLineCountry = texthelp.getField(thisLine, "	", 1);
						if (thisLineCountry.equals(countryAbbrev)) {

							Vector spots = texthelp.explode(thisLine, "	");
							for (int j=1; j<spots.size(); j++) {
								String thisJ = (String)spots.get(j);
								if (!thisJ.equals("0")) {
									String theMonth = texthelp.getField (headerLine, "	", (j+1));
									theMonth = texthelp.replaceAll(theMonth, "P_", "");
									theMonth = myDate.getSQLFormatFromResultsDateFormat(theMonth);

									if (doDateFormatting) {

										if (currIntervalChoice.equals("Quarterly"))
											theMonth = texthelp.getMatchingAll_ReturnIndexVal (mappingsDate, theMonth, 1, 0);
										else
											theMonth = myDate.getShortDate (theMonth, SESSdatecontrolformat);
									}

									Vector thisInsert = new Vector();
									thisInsert.add (theMonth);
									thisInsert.add ("Launch");
									thisInsert.add ("");  // empty in all others.. shown globally on screen
									thisInsert.add (texthelp.getFloatDisplayFormatted(thisJ, 2));
									Vector emptyrefs = new Vector();
									thisInsert.add (emptyrefs);

									ret.insertElementAt (thisInsert, 0);

									break;
								}
							}
							break;
						}
					}
				}
			}
		}



		return ret;


	}

	/**
	 * Return Vector of Vectors back - i.e .lines from a file.. that are tab delim, but potentially unknown column order.  Pass the columns looking for - assumed in header, and a matching colname and value.. i.e. for returned rows
	 *
	 * @param pathToFile (String):  path to file
	 * @param collist (Vector):  list of column names to find.. will find case insensitive
	 * @param colmatchname (String):  colmatchname
	 * @param colmatchval (String):  colmatchval
	 * @param caseSensitiveCols (boolean):  whether to look for column case senstivie or not
	 * @param caseSensitiveVal (boolean):  whether to look for column value match -  case senstivie or not
	 *
	 * @return Vector of Strings - includes empty at start.. the choices from the choiceStart, and numChoices many choices
	 */
	public static Vector getRowColsFromTabFiles(String pathToFile, Vector collist, String colmatchname, String colmatchval, boolean caseSensitiveCols, boolean caseSensitiveVal) {

		Vector ret = new Vector();

		if (filehelp.checkFile(pathToFile)) {

			Vector fromFile = filehelp.getFileContentsToVector (pathToFile);

			if (fromFile == null)
				ret = null;
			else
				ret = getRowColsFromTabFiles(fromFile, collist, colmatchname, colmatchval, caseSensitiveCols, caseSensitiveVal);
		}

		return ret;


	}



	/**
	 * Return Vector of Vectors back - i.e .lines from a file.. that are tab delim, but potentially unknown column order.  Pass the columns looking for - assumed in header, and a matching colname and value.. i.e. for returned rows
	 *
	 * @param pathToFile (String):  path to file
	 * @param collist (Vector):  list of column names to find.. will find case insensitive
	 * @param colmatchname (String):  colmatchname
	 * @param colmatchval (String):  colmatchval
	 * @param caseSensitiveCols (boolean):  whether to look for column case senstivie or not
	 * @param caseSensitiveVal (boolean):  whether to look for column value match -  case senstivie or not
	 *
	 * @return Vector of Strings - includes empty at start.. the choices from the choiceStart, and numChoices many choices
	 */
	public static Vector getRowColsFromTabFiles(Vector fromFile, Vector collist, String colmatchname, String colmatchval, boolean caseSensitiveCols, boolean caseSensitiveVal) {

		Vector ret = new Vector();

		if (fromFile != null) {

			if (fromFile.size()>0) {

				String headerRow = (String)fromFile.get(0);
				Vector expCols = texthelp.explode(headerRow, "	");
				Vector expColsUpper = new Vector();
				for (int i=0; i<expCols.size(); i++) {
					String thisS = (String)expCols.get(i);
					if (caseSensitiveCols)
						expColsUpper.add(thisS); // hold same.. so upper Vecs are the same
					else
						expColsUpper.add(thisS.toUpperCase());
				}

				Vector collistUppers = new Vector();
				for (int i=0; i<collist.size(); i++) {
					String thisS = (String)collist.get(i);
					if (caseSensitiveCols)
						collistUppers.add(thisS);
					else
						collistUppers.add(thisS.toUpperCase());
				}

				String colmatchnameUpper = colmatchname;
				if (caseSensitiveCols)
					colmatchnameUpper = colmatchname.toUpperCase();


				int[] theIndexVals = new int[collist.size()];
				for (int i=0; i<collist.size(); i++) {
					theIndexVals[i] = -1;
				}
				int indexMain = -1;

				for (int i=0; i<expColsUpper.size(); i++) {
					String thisC = (String)expColsUpper.get(i);
					if (colmatchnameUpper.equals(thisC)) {
						indexMain = i;
					}

					for (int j=0; j<collistUppers.size(); j++) {
						String thisColJ = (String)collistUppers.get(j);
						if (thisColJ.equals(thisC))
							theIndexVals[j] = i;
					}
				}

				boolean allFound = true;
				if (indexMain == -1)
					allFound = false;
				else {
					for (int i=0; i<collistUppers.size(); i++) {
						if (theIndexVals[i] == -1)
							allFound = false;
					}
				}

				if (allFound) {

					String colmatchvalUpper = colmatchval.toUpperCase();

					for (int i=1; i<fromFile.size(); i++) {
						String thisLine = (String)fromFile.get(i);
						String thisValLineMatch = texthelp.getField (thisLine, "	", indexMain+1);
						boolean addIt = false;

						if (caseSensitiveVal) {
							if (thisValLineMatch.equals(colmatchval)) {
								addIt = true;
							}
						}
						else {
							String thisValLineMatchUpper = thisValLineMatch.toUpperCase();
							if (thisValLineMatchUpper.equals(colmatchvalUpper)) {
								addIt = true;
							}

						}

						if (addIt) {
							Vector thisSet = new Vector();
							for (int j=0; j<collistUppers.size(); j++) {
								thisSet.add (texthelp.getField (thisLine, "	", theIndexVals[j]+1 )); // index is vector based, getField is 1 based
							}
							ret.add (thisSet);
						}
					}
				}
			}
		}

		return ret;

	}


	/**
	 * Return Vector of Vectors back - i.e .lines from a file.. that are tab delim, but potentially unknown column order.  Pass the columns looking for - assumed in header, and a matching colname and value.. i.e. for returned rows
	 *
	 * @param pathToFile (String):  path to file
	 * @param collist (Vector):  list of column names to find.. will find case insensitive
	 * @param caseSensitiveCols (boolean):  whether to look for column case senstivie or not
	 *
	 * @return Vector of Strings - includes empty at start.. the choices from the choiceStart, and numChoices many choices
	 */
	public static Vector getRowColsFromTabFilesAllRows(String pathToFile, Vector collist,  boolean caseSensitiveCols) {

		Vector ret = new Vector();

		if (filehelp.checkFile(pathToFile)) {

			Vector fromFile = filehelp.getFileContentsToVector (pathToFile);

			if (fromFile == null)
				ret = null;
			else
				ret = getRowColsFromTabFilesAllRows(fromFile, collist, caseSensitiveCols);
		}

		return ret;


	}

	/**
	 * Return Vector of Vectors back - i.e .lines from a file.. that are tab delim, but potentially unknown column order.  Pass the columns looking for - assumed in header, and a matching colname and value.. i.e. for returned rows
	 *
	 * @param pathToFile (String):  path to file
	 * @param collist (Vector):  list of column names to find.. will find case insensitive
	 * @param caseSensitiveCols (boolean):  whether to look for column case senstivie or not
	 *
	 * @return Vector of Strings - includes empty at start.. the choices from the choiceStart, and numChoices many choices
	 */
	public static Vector getRowColsFromTabFilesAllRows(Vector fromFile, Vector collist, boolean caseSensitiveCols) {

		Vector ret = new Vector();

		if (fromFile != null) {

			if (fromFile.size()>0) {

				String headerRow = (String)fromFile.get(0);
				Vector expCols = texthelp.explode(headerRow, "	");
				Vector expColsUpper = new Vector();
				for (int i=0; i<expCols.size(); i++) {
					String thisS = (String)expCols.get(i);
					if (caseSensitiveCols)
						expColsUpper.add(thisS); // hold same.. so upper Vecs are the same
					else
						expColsUpper.add(thisS.toUpperCase());
				}

				Vector collistUppers = new Vector();
				for (int i=0; i<collist.size(); i++) {
					String thisS = (String)collist.get(i);
					if (caseSensitiveCols)
						collistUppers.add(thisS);
					else
						collistUppers.add(thisS.toUpperCase());
				}


				int[] theIndexVals = new int[collist.size()];
				for (int i=0; i<collist.size(); i++) {
					theIndexVals[i] = -1;
				}

				for (int i=0; i<expColsUpper.size(); i++) {
					String thisC = (String)expColsUpper.get(i);
					for (int j=0; j<collistUppers.size(); j++) {
						String thisColJ = (String)collistUppers.get(j);
						if (thisColJ.equals(thisC))
							theIndexVals[j] = i;
					}
				}

				boolean allFound = true;
				for (int i=0; i<collistUppers.size(); i++) {
					if (theIndexVals[i] == -1)
						allFound = false;
				}

				if (allFound) {


					for (int i=1; i<fromFile.size(); i++) {
						String thisLine = (String)fromFile.get(i);

						Vector thisSet = new Vector();
						for (int j=0; j<collistUppers.size(); j++) {
							thisSet.add (texthelp.getField (thisLine, "	", theIndexVals[j]+1 )); // index is vector based, getField is 1 based
						}
						ret.add (thisSet);
					}
				}
			}
		}

		return ret;

	}


	// overload
	public static Vector getDiffsForLROCompare(Vector atts1, Vector atts2, Vector detaildefs, Vector countries,
				Vector algorithmclasses, String SESSdatecontrolformat, boolean compareOfScenarioToItsPlan,
				boolean subsetCountries, Vector countriesCanView, boolean compareOfScenarioPlanToForecasts, String SESSnumberformat_decimal) {

		return getDiffsForLROCompare(atts1, atts2, detaildefs, countries,
				algorithmclasses, SESSdatecontrolformat, compareOfScenarioToItsPlan,
				subsetCountries, countriesCanView, compareOfScenarioPlanToForecasts, false, SESSnumberformat_decimal, new Vector());

	}

	public static Vector getDiffsForLROCompare(Vector atts1, Vector atts2, Vector detaildefs, Vector countries,
			Vector algorithmclasses, String SESSdatecontrolformat, boolean compareOfScenarioToItsPlan,
			boolean subsetCountries, Vector countriesCanView, boolean compareOfScenarioPlanToForecasts,
			boolean compareOfPlanToCountryAttributes, String SESSnumberformat_decimal, Vector idsNamesSKUs) {

		return getDiffsForLROCompare(atts1, atts2, detaildefs, countries,
				algorithmclasses, SESSdatecontrolformat, compareOfScenarioToItsPlan,
				subsetCountries, countriesCanView, compareOfScenarioPlanToForecasts,compareOfPlanToCountryAttributes, SESSnumberformat_decimal, idsNamesSKUs, new Vector(), null);
	}


	/**
	 * Return the diffs of two plans, two scenarios, or a plan to its scenario (offset in props)
	 *
	 * @param atts1 (Vector of Vectors):  the return from a getAtts Vector call
	 * @param atts2 (Vector of Vectors):  the return from a getAtts Vector call
	 * @param detaildefs (Vector of Vectors):  from get defs call
	 * @param algorithmclasses (Vector of Vectors):  from call to getClassesFull
	 * @param compareOfScenarioToItsPlan (boolean):  whether there is offset - i.e. atts1 is a scenario, and atts2 is its plan.  If true, the detaildefs are the scenario detail defs
	 *
	 * @return Vector of Vectors - Diffs.. includes a country break line that should be not counted for # diffs by the caller
	 * -> flagImage, country name, name of attributes, Left side value, Right side value;
	 */

	public static Vector getDiffsForLROCompare(Vector atts1, Vector atts2, Vector detaildefs, Vector countries,
				Vector algorithmclasses, String SESSdatecontrolformat, boolean compareOfScenarioToItsPlan,
				boolean subsetCountries, Vector countriesCanView, boolean compareOfScenarioPlanToForecasts,
				boolean compareOfPlanToCountryAttributes, String SESSnumberformat_decimal, Vector idsNamesSKUs, Vector refTypes, RefTypeTranslator refTypeTranslator) {
		return getDiffsForLROCompare(atts1, atts2, detaildefs, countries,
				algorithmclasses, SESSdatecontrolformat, compareOfScenarioToItsPlan,
				subsetCountries, countriesCanView, compareOfScenarioPlanToForecasts,
				compareOfPlanToCountryAttributes, SESSnumberformat_decimal, idsNamesSKUs, refTypes, refTypeTranslator, 12, "");
		
	}
	
	public static Vector getDiffsForLROCompare(Vector atts1, Vector atts2, Vector detaildefs, Vector countries,
				Vector algorithmclasses, String SESSdatecontrolformat, boolean compareOfScenarioToItsPlan,
				boolean subsetCountries, Vector countriesCanView, boolean compareOfScenarioPlanToForecasts,
				boolean compareOfPlanToCountryAttributes, String SESSnumberformat_decimal, Vector idsNamesSKUs, Vector refTypes, RefTypeTranslator refTypeTranslator, int indexForSKU, String productID) {

		Vector ret = new Vector();

		datehelp myDate  = new datehelp();

		Vector countries1 = new Vector();
		Vector countries2 = new Vector();
		for (int i=0; i<atts1.size(); i++) {
			Vector thisV = (Vector)atts1.get(i);
			if (thisV.size()>=10) {
				String thisVCID = (String)thisV.get(10);
				if (!countries1.contains(thisVCID) && !thisVCID.equals(""))
					countries1.add (thisVCID);
			}
		}
		for (int i=0; i<atts2.size(); i++) {
			Vector thisV = (Vector)atts2.get(i);
			if (thisV.size()>=10) {
				String thisVCID = (String)thisV.get(10);
				if (!countries2.contains(thisVCID) && !thisVCID.equals(""))
					countries2.add (thisVCID);
			}
		}

		Vector classIDsMultiSKU = new Vector();
		if (idsNamesSKUs.size()>0) {
			for (int i=0; i<detaildefs.size(); i++) {
				Vector thisV = (Vector)detaildefs.get(i);
				String thisRule = (String)thisV.get(8);
				if (thisRule.indexOf("MULTSKU")>-1) {
					classIDsMultiSKU.add((String)thisV.get(0));
				}
			}
		}

		// do the general settings first

		int maxVolMonths = -1;  // hold the months or quarters.. for country to plan there is scan over that period for existence of ref events recurring from country settings
		String startOfPlan = ""; // hold the start for traverse for country to plan compare
		String currIntervalChoice = "Monthly";  // if start of plan has ' Q' then its a quarterly type

		for (int i=0; i<detaildefs.size(); i++) {
			Vector thisV = (Vector)detaildefs.get(i);

			if (compareOfScenarioPlanToForecasts)
				continue; // no such thing here.. this type is only countries

			String thisClassID = (String)thisV.get(0);
			String thisRule = (String)thisV.get(8);
			String thisType = (String)thisV.get(3);
			String thisName = texthelp.backToAllForWebPage((String)thisV.get(1));

			if (thisRule.indexOf("HIDDEN")>-1)  // some hidden general defs
				continue;
			
			if (compareOfScenarioToItsPlan && thisRule.indexOf("ATT_PLAN")==-1)
				continue;

			
			String val1Temp = texthelp.backToAllForWebPage(texthelp.getMatchingAll_ReturnIndexVal (atts1, thisClassID, 5, 0));
			if (thisClassID.equals(gc.attribute_CPS_PeriodsOfRuntime) && !val1Temp.equals(""))
				maxVolMonths = Integer.valueOf(val1Temp).intValue();
			else if (thisClassID.equals(gc.attribute_CPS_StartOfRun))
				startOfPlan = val1Temp;
			
			
			if (thisRule.indexOf("COUNTRY")==-1) {

				String val1 = texthelp.backToAllForWebPage(texthelp.getMatchingAll_ReturnIndexVal (atts1, thisClassID, 5, 0));

				if (compareOfPlanToCountryAttributes)
					continue; // there are no attributes that are general at the country level.. just country attributes.  Continue here to ensure we get Month and startoPlan filled


				String compareClassID2 = thisClassID;

				// here.. its now the same classes ID in 4.1.0
				String val2 = texthelp.backToAllForWebPage(texthelp.getMatchingAll_ReturnIndexVal (atts2, compareClassID2, 5, 0));

				if (thisType.equals(gc.type_Date)) {
					if (!val1.equals(""))
						val1 = myDate.getDateControlFmtFromSqlDate (val1, SESSdatecontrolformat);
					if (!val2.equals(""))
						val2 = myDate.getDateControlFmtFromSqlDate (val2, SESSdatecontrolformat);
				}

				if (thisType.equals(gc.type_CheckBox)) {

					if (!val1.equals(""))
						val1 = "<i style=\"color:green;\" class=\"fa fa-check fa-lg\"></i>";
					if (!val2.equals(""))
						val2 = "<i style=\"color:green;\" class=\"fa fa-check fa-lg\"></i>";
				}


				if (!val1.equals(val2)) {

					// double check that if there is padding of zeros or not.. on two floats.. i.e. 49.6 and 49.60
					boolean stillADiff = true;
					if (texthelp.isNumeric(val1) && texthelp.isNumeric(val2)) {
						float thisVal1Float = Float.valueOf(val1).floatValue();
						float thisVal2Float = Float.valueOf(val2).floatValue();
						if (thisVal1Float == thisVal2Float)
							stillADiff = false;
					}

					if (stillADiff) {

						if (texthelp.isNumeric(val1))
							val1 = texthelp.replaceAll(val1, ".", SESSnumberformat_decimal);
						if (texthelp.isNumeric(val2))
							val2 = texthelp.replaceAll(val2, ".", SESSnumberformat_decimal);

						ret.add (texthelp.getVectorForItems("", "", thisName, val1, val2, thisClassID, "" , ""));
					}
				}
			}
		}

		if (startOfPlan.indexOf(" Q")>-1)
			currIntervalChoice = "Quarterly";


		if (countries1.size() != countries2.size() && !compareOfScenarioPlanToForecasts && !compareOfPlanToCountryAttributes) {
			ret.add (texthelp.getVectorForItems("", "", "Count of Countries", String.valueOf(countries1.size()), String.valueOf(countries2.size()), "", "" , ""));
		}

		String lastCountry = "";
		for (int c=0; c<countries.size(); c++) {
			Vector thisC = (Vector)countries.get(c);
			String thisCID = (String)thisC.get(0);
			String thisAbbrev = (String)thisC.get(13);
			String flagImage = texthelp.getFlagDisplay(thisAbbrev);
			String thisCountryName = texthelp.backToAllForWebPage ((String)thisC.get(8) + " ("+thisAbbrev+")");
			if (countries1.contains(thisCID) || countries2.contains(thisCID)) {

				if (countries1.contains(thisCID) && !countries2.contains(thisCID)) {

					if (compareOfScenarioPlanToForecasts)
						continue; // just not know in pricing inputs.. yet

					if (compareOfPlanToCountryAttributes)
						continue; // this is not a valid diff.. only looking at the plan countries.. to countries, counties could be bigger set.. and that is fine here

					if (!lastCountry.equals(thisCID))
						ret.add (texthelp.getVectorForItems(flagImage, thisCountryName, "", "", "", "", "" , thisCID));

					lastCountry = thisCID;

					ret.add (texthelp.getVectorForItems("", "", "-", "(settings present)", "(settings not present)", "", "" , thisCID));
				}
				else if (!countries1.contains(thisCID) && countries2.contains(thisCID)) {

					if (compareOfPlanToCountryAttributes)
						continue; // this is not a valid diff.. only looking at the plan countries.. to countries, counties could be bigger set.. and that is fine here

					if (!lastCountry.equals(thisCID))
						ret.add (texthelp.getVectorForItems(flagImage, thisCountryName, "", "", "", "", "" , thisCID));

					lastCountry = thisCID;

					ret.add (texthelp.getVectorForItems("", "", "-", "(settings not present)", "(settings present)", "", "" , thisCID));
				}
				else {

					for (int i=0; i<detaildefs.size(); i++) {

						Vector thisV = (Vector)detaildefs.get(i);
						String thisClassID = (String)thisV.get(0);
						String thisRule = (String)thisV.get(8);
						String thisType = (String)thisV.get(3);

						int fixIndexForSKU = indexForSKU;

//						if (thisClassID.equals(gc.attribute_CPS_Events)) {
//							fixIndexForSKU = 13;
//						}
						
						if (thisRule.indexOf("COUNTRY")>-1) {
							Vector thisSKULoop = new Vector();

							//Manually getting CPS events here instead of as MULTSKU
							//Too far into QA to make such a sweeping change at this point
							if (classIDsMultiSKU.contains(thisClassID) || thisClassID.equals(gc.attribute_CPS_Events)) {
								for (int s=0; s<idsNamesSKUs.size(); s++) {
									thisSKULoop.add((Vector)idsNamesSKUs.get(s));
								}
							}
							else
								thisSKULoop.add(texthelp.getVectorForItems("", ""));  // match on empty rel1 id

							for (int s=0; s<thisSKULoop.size(); s++) {
								
								Vector thisS = (Vector)thisSKULoop.get(s);
								String thisSKUID = (String)thisS.get(0);
								String thisSKUName = texthelp.backToAllForWebPage((String)thisS.get(1));

								String thisName = texthelp.backToAllForWebPage((String)thisV.get(1));


								boolean containsSkuAndCountry = false;
								lro myLRO = new lro();
								if (!productID.equals("") && !thisSKUID.equals("")) {
									String skuCountry = myLRO.getSKUcountry(productID, thisSKUID);
									Vector skuCountries = texthelp.explode (skuCountry, "^");
									if (skuCountries.contains("ALL") || skuCountries.contains(thisAbbrev) )
										containsSkuAndCountry = true;
								}
								else 
									containsSkuAndCountry = true;

								if(containsSkuAndCountry){
																		
									if (!thisSKUName.equals(""))
										thisName += " ("+thisSKUName+")";
									String val1 = texthelp.backToAllForWebPage(texthelp.getMatchingAll_ReturnIndexVal (atts1, thisClassID, thisCID, thisSKUID, 5, 10, fixIndexForSKU, 0));
									
									String compareClassID2 = thisClassID;
	
									// here.. in 4.1.0.. classes all the same now..
	
									if (compareOfPlanToCountryAttributes) {
	
										// some plan level country attributes are not at the country level.. i.e. just specific to a plan, skip these
										
										if (thisClassID.equals(gc.attribute_CPS_VolumeForecast)
											|| thisClassID.equals(gc.attribute_CPS_LaunchDate)
											|| thisClassID.equals(gc.attribute_CPS_LaunchPrice)
											|| thisClassID.equals(gc.attribute_CPS_LaunchLow)
											|| thisClassID.equals(gc.attribute_CPS_LaunchHigh)
											|| thisClassID.equals(gc.attribute_CPS_FixedPrice)
											|| thisClassID.equals(gc.attribute_CPS_FixedDate)
											|| thisClassID.equals(gc.attribute_CPS_InformalValues)
											|| thisClassID.equals(gc.attribute_CPS_DiscountValues)
										)
											continue;
	
									}
	
									String val2 = texthelp.backToAllForWebPage(texthelp.getMatchingAll_ReturnIndexVal (atts2, compareClassID2, thisCID, thisSKUID, 5, 10, fixIndexForSKU, 0));
									if (val2.equals("") && compareOfScenarioPlanToForecasts) {
										
										// if not present in the forecasts data, then not a difference.. either configuration of the attributes says not to be set, or not collected yet
										String val2DetailID = texthelp.backToAllForWebPage(texthelp.getMatchingAll_ReturnIndexVal (atts2, compareClassID2, thisCID, thisSKUID, 5, 10, fixIndexForSKU, 9));
										if (val2DetailID.equals(""))
											continue;
	
									}
	
									if (thisType.equals(gc.type_Date)) {
										if (!val1.equals(""))
											val1 = myDate.getDateControlFmtFromSqlDate (val1, SESSdatecontrolformat);
										if (!val2.equals(""))
											val2 = myDate.getDateControlFmtFromSqlDate (val2, SESSdatecontrolformat);
									}
									else if (thisType.equals(gc.type_CheckBox)) {
	
										if (!val1.equals(""))
											val1 = "<i style=\"color:green;\" class=\"fa fa-check fa-lg\"></i>";
										if (!val2.equals(""))
											val2 = "<i style=\"color:green;\" class=\"fa fa-check fa-lg\"></i>";
									}
									else if(thisClassID.equals(gc.attribute_CPS_ReferenceableTypes))
									{
										
										if(refTypeTranslator != null)
										{
											val1 = refTypeTranslator.caretToEnglish(val1);
											val2 = refTypeTranslator.caretToEnglish(val2);
	
											if(val1.equals(""))
												val1 = "(none)";
	
											if(val2.equals(""))
												val2 = "(none)";
										}
										else
										{
											val1 = "";
											val2 = "";
										}
									}
									else if (thisClassID.equals(gc.attribute_CPS_RefBasket) || thisClassID.equals(gc.attribute_CPS_RefBasket)) {
	
										if (compareOfPlanToCountryAttributes) {
	
											// often the country settings have a superset of all countries, and if the plan has only a subset of those, plan add will have trimmed out the non-applicable countries (to the plan).   As such, the country setting values should be trimeed to only include countries from the countries vector (from the plan)
	
											String newval2 = "";
	
											if (!val2.equals("")) {
												Vector expVal2 = texthelp.explode(val2, ":");
												for (int b=0; b<expVal2.size(); b++) {
													String thisB = (String)expVal2.get(b);
													Vector expBasket = texthelp.explode(thisB, "^");
	
													String thisBasketVal = "";
													for (int b2=0; b2<expBasket.size(); b2++){
														String thisB2ID = (String)expBasket.get(b2);
														String checkInCountryExistsInPlan = texthelp.backToAllForWebPage(texthelp.getMatchingAll_ReturnIndexVal (countries, thisB2ID, 0, 0));
														if (!checkInCountryExistsInPlan.equals("")) {
															if (thisBasketVal.equals(""))
																thisBasketVal = thisB2ID;
															else
																thisBasketVal += "^"+thisB2ID;
														}
													}
	
													if (b>0)
														newval2 += ":";
	
													newval2 += thisBasketVal;
												}
											}
	
											val2 = newval2;
	
										}
	
										if (!val1.equals(val2)) {
	
											boolean foundDiffs = false; // in case different order?
	
											Vector expVal1 = texthelp.explode(val1, ":");
											Vector expVal2 = texthelp.explode(val2, ":");
	
											val1 = "";
											val2 = "";
	
	
											int maxBaskets = expVal1.size();
											if (expVal2.size()>maxBaskets)
												maxBaskets = expVal2.size();
	
											if (expVal1.size() != expVal2.size() && maxBaskets>1) {
												val1 = expVal1.size()+" basket(s)<br><br>";
												val2 = expVal2.size()+" basket(s)<br><br>";
											}
											for (int b=1; b<=maxBaskets; b++) {
	
												String thisVal1 = "";
												String thisVal2 = "";
	
												if (b<=expVal1.size())
													thisVal1 = (String)expVal1.get(b-1);
												if (b<=expVal2.size())
													thisVal2 = (String)expVal2.get(b-1);
	
												Vector exp1 = texthelp.explode(thisVal1, "^");
												Vector exp2 = texthelp.explode(thisVal2, "^");
	
												thisVal1 = "";
												thisVal2 = "";
	
	
												int countCountries = 0;
												for (int z=0 ;z<exp1.size(); z++) {
													String thisCountryIDZ = (String)exp1.get(z);
													if (!thisCountryIDZ.equals("")) {
														countCountries++;
													}
												}
	
												int countCountries2 = 0;
												for (int z=0 ;z<exp2.size(); z++) {
													String thisCountryIDZ = (String)exp2.get(z);
													if (!thisCountryIDZ.equals("")) {
														countCountries2++;
													}
												}
	
												if (b>1) {
													thisVal1 = "<br><br>(secondary basket, "+countCountries+")<br>";
													thisVal2 = "<br><br>(secondary basket, "+countCountries2+")<br>";
												}
												else {
													if (maxBaskets==1) {
														thisVal1 = "("+countCountries+")<br>";
														thisVal2 = "("+countCountries2+")<br>";
													}
													else {
														thisVal1 = "(primary basket, "+countCountries+")<br>";
														thisVal2 = "(primary basket, "+countCountries2+")<br>";
													}
												}
	
												if (countCountries != countCountries2)
													foundDiffs = true;
	
												// give ret in words
	
												for (int c2=0; c2<countries.size(); c2++) {
													Vector thisC2 = (Vector)countries.get(c2);
													String thisCID2 = (String)thisC2.get(0);
													String thisAbbrev2 = (String)thisC2.get(13);
													String flagImage2 = texthelp.getFlagDisplay(thisAbbrev2);
													if (exp1.contains(thisCID2) || exp2.contains(thisCID2)) {
														if (exp1.contains(thisCID2) && !exp2.contains(thisCID2)) {
															thisVal1 += "<br>"+flagImage2+" "+thisAbbrev2+" present";
															thisVal2 += "<br>"+flagImage2+" "+thisAbbrev2+" not present";
															foundDiffs = true;
														}
														else if (!exp1.contains(thisCID2) && exp2.contains(thisCID2)) {
															thisVal1 += "<br>"+flagImage2+" "+thisAbbrev2+" not present";
															thisVal2 += "<br>"+flagImage2+" "+thisAbbrev2+" present";
															foundDiffs = true;
														}
													}
												}
	
												val1 += thisVal1;
												val2 += thisVal2;
	
	
											}
	
											if (!foundDiffs) {
												val1 = "";
												val2 = ""; // to not show as a diff
											}
	
										}
									}
									else if (thisClassID.equals(gc.attribute_CPS_Events)) {
										if (compareOfPlanToCountryAttributes) {
											// here the laid out ref events for the rule... are just compared against the existing recurring ref events.. all other events are deemed OK in the plan and not a difference
	
											String newval1 = "";
											String newval2 = "";
	
											if (startOfPlan.equals("") || maxVolMonths==-1) {
												newval1 += "<br>ERROR: The plan does not have an overall start date and/or runtime periods set?";
	
											}
											else {
	
												// scan against recurring ref events.. over the launch period
	
												// this section is a subset of the on screen add option in ref events for mass add of missing ones
												
												String thisCountryLaunchDate = texthelp.backToAllForWebPage(texthelp.getMatchingAll_ReturnIndexVal (atts1, gc.attribute_CPS_LaunchDate, thisCID, 5, 10, 0));
												String thisCountryVal = val1;
	
												String thisCountryValRecurring = val2;
	
												Vector theMonths = texthelp.explode (thisCountryValRecurring, "^");
	
												String theRollingDate = startOfPlan;
	
												if (currIntervalChoice.equals("Quarterly")) {
	
													String theQPart = texthelp.getField (theRollingDate, " ", 2);
	
													if (theQPart.equals("Q1"))
														theQPart = "01";
													else if (theQPart.equals("Q2"))
														theQPart = "04";
													else if (theQPart.equals("Q3"))
														theQPart = "07";
													else if (theQPart.equals("Q4"))
														theQPart = "10";
	
													theRollingDate = texthelp.getField (theRollingDate, " ", 1)+"-"+theQPart+"-01";
												}
	
	
												for (int p=1; p<maxVolMonths; p++) {
	
													theRollingDate = myDate.addDays (theRollingDate, 45);
													if (currIntervalChoice.equals("Quarterly")) {
														// two more months to get in next quarter
														String theMonthQ = texthelp.getField (theRollingDate, "-", 2);
														theRollingDate = texthelp.getField (theRollingDate, "-", 1)+"-"+theMonthQ+"-01";
														theRollingDate = myDate.addDays (theRollingDate, 45);
														theMonthQ = texthelp.getField (theRollingDate, "-", 2);
														theRollingDate = texthelp.getField (theRollingDate, "-", 1)+"-"+theMonthQ+"-01";
														theRollingDate = myDate.addDays (theRollingDate, 45);
													}
	
													String theMonth = texthelp.getField (theRollingDate, "-", 2);
													theRollingDate = texthelp.getField (theRollingDate, "-", 1)+"-"+theMonth+"-01";
	
													if (
														(theMonth.equals("01") && theMonths.contains("JAN"))
														|| (theMonth.equals("02") && theMonths.contains("FEB"))
														|| (theMonth.equals("03") && theMonths.contains("MAR"))
														|| (theMonth.equals("04") && theMonths.contains("APR"))
														|| (theMonth.equals("05") && theMonths.contains("MAY"))
														|| (theMonth.equals("06") && theMonths.contains("JUN"))
														|| (theMonth.equals("07") && theMonths.contains("JUL"))
														|| (theMonth.equals("08") && theMonths.contains("AUG"))
														|| (theMonth.equals("09") && theMonths.contains("SEP"))
														|| (theMonth.equals("10") && theMonths.contains("OCT"))
														|| (theMonth.equals("11") && theMonths.contains("NOV"))
														|| (theMonth.equals("12") && theMonths.contains("DEC"))
	
													 ) {
	
														String thisDate = theRollingDate;
														if (currIntervalChoice.equals("Quarterly")) {
															String thisDateMonth = texthelp.getField (thisDate, "-", 2);
															if (thisDateMonth.equals("01"))
																thisDateMonth = "Q1";
															else if (thisDateMonth.equals("04"))
																thisDateMonth = "Q2";
															else if (thisDateMonth.equals("07"))
																thisDateMonth = "Q3";
															else if (thisDateMonth.equals("10"))
																thisDateMonth = "Q4";
															thisDate = texthelp.getField (thisDate, "-", 1)+" "+thisDateMonth;
														}
	
	
														if (thisDate.compareTo(thisCountryLaunchDate)<=0)
															continue;
	
	
														String theRefEventsVal = "Reference~"+thisDate+"~";
	
														if (thisCountryVal.indexOf(theRefEventsVal) ==-1) {
	
															String thisJ_DateDisplay = thisDate;
															if (currIntervalChoice.equals("Monthly"))
																thisJ_DateDisplay = myDate.getShortDate (thisJ_DateDisplay, SESSdatecontrolformat);
	
															newval1 += "<br>Missing reference event for "+thisJ_DateDisplay;
															newval2 += "<br>Has recurring reference event(s) for "+texthelp.replaceAll (thisCountryValRecurring, "^", ", ");
	
														}
													}
												}
	
											}
	
											// last set the main val1 and val2.. for compare and row add (if different)
											val1 = newval1;
											val2 = newval2;
	
	
										}
										else {
																						
											if (!val1.equals(val2)) {
	
												Vector expEvents = texthelp.explode (val1, "^");
												int countEvents = 0;
												for (int z=0 ;z<expEvents.size(); z++) {
													String thisEventZ = (String)expEvents.get(z);
													if (!thisEventZ.equals("")) {
														countEvents++;
													}
												}
	
												Vector expEvents2 = texthelp.explode (val2, "^");
												int countEvents2 = 0;
												for (int z=0 ;z<expEvents2.size(); z++) {
													String thisEventZ = (String)expEvents2.get(z);
													if (!thisEventZ.equals("")) {
														countEvents2++;
													}
												}
	
												boolean foundDiffs = false; // in case different order?
	
												if (expEvents != expEvents2)
													foundDiffs = true;
	
												// give ret in words
												Vector exp1 = new Vector();
												if (!val1.equals(""))
													exp1 = texthelp.explode(val1, "^");
												Vector exp2 = new Vector();
												if (!val2.equals(""))
													exp2 = texthelp.explode(val2, "^");
												
												for (int e=0; e<exp1.size();e++) {
													String thisOne = (String)exp1.get(e);
													if (thisOne.indexOf("Reference")>-1 && !thisOne.endsWith("~~"))
														exp1.set(e, thisOne+"~");
												}
												for (int e=0; e<exp2.size();e++) {
													String thisOne = (String)exp2.get(e);
													if (thisOne.indexOf("Reference")>-1 && !thisOne.endsWith("~~"))
														exp2.set(e, thisOne+"~");
												}
	
												val1 = "("+countEvents+")";
												val2 = "("+countEvents2+")";													
												
												for (int c2=0; c2<exp1.size(); c2++) {
													String thisOne = (String)exp1.get(c2);
													String thisOneType = texthelp.getField (thisOne, "~", 1);
													String thisOneDate = texthelp.getField (thisOne, "~", 2);
													String thisOneCut = texthelp.getField (thisOne, "~", 3);
													String thisOnePrint = thisOneType+": "+myDate.getDateControlFmtFromSqlDate (thisOneDate, SESSdatecontrolformat);
													if (!thisOneCut.equals(""))
														thisOnePrint += " ("+texthelp.replaceAll(thisOneCut, ".", SESSnumberformat_decimal)+")";
	
													if (!exp2.contains(thisOne)) {
	
														boolean priceTextualDiff_OKNumerically = false;
														if (!thisOneCut.equals("")) {
															// here .. if the value is numerically the same as one from the other set.. i.e. 0.2 vs. 0.20 .. then they are considered the same
	
															for (int e=0; e<exp2.size(); e++) {
																String thisE = (String)exp2.get(e);
																String thisE_Type = texthelp.getField(thisE, "~", 1);
																String thisE_Date = texthelp.getField(thisE, "~", 2);
																String thisE_PriceCut = texthelp.getField(thisE, "~", 3);
	
																if (thisOneType.equals(thisE_Type) && thisE_Date.equals(thisOneDate)) {
																	float thisOneCutFloat = Float.valueOf(thisOneCut).floatValue();
																	float thisE_PriceCutFloat = Float.valueOf(thisE_PriceCut).floatValue();
	
																	if (thisOneCutFloat == thisE_PriceCutFloat)
																		priceTextualDiff_OKNumerically = true;
	
																	break;
																}
															}
														}
	
														if (!priceTextualDiff_OKNumerically) {
															val1 += "<br>"+thisOnePrint+" present";
															val2 += "<br>"+thisOnePrint+" not present";
															foundDiffs = true;
														}
													}
												}
	
												for (int c2=0; c2<exp2.size(); c2++) {
													String thisOne = (String)exp2.get(c2);
													String thisOneType = texthelp.getField (thisOne, "~", 1);
													String thisOneDate = texthelp.getField (thisOne, "~", 2);
													String thisOneCut = texthelp.getField (thisOne, "~", 3);
													String thisOnePrint = thisOneType+": "+myDate.getDateControlFmtFromSqlDate (thisOneDate, SESSdatecontrolformat);
													if (!thisOneCut.equals(""))
														thisOnePrint += " ("+texthelp.replaceAll(thisOneCut, ".", SESSnumberformat_decimal)+")";

													if (!exp1.contains(thisOne)) {
	
														boolean priceTextualDiff_OKNumerically = false;
														if (!thisOneCut.equals("")) {
															// here .. if the value is numerically the same as one from the other set.. i.e. 0.2 vs. 0.20 .. then they are considered the same
	
															for (int e=0; e<exp1.size(); e++) {
																String thisE = (String)exp1.get(e);
																String thisE_Type = texthelp.getField(thisE, "~", 1);
																String thisE_Date = texthelp.getField(thisE, "~", 2);
																String thisE_PriceCut = texthelp.getField(thisE, "~", 3);
	
																if (thisOneType.equals(thisE_Type) && thisE_Date.equals(thisOneDate)) {
	
																	float thisOneCutFloat = Float.valueOf(thisOneCut).floatValue();
																	float thisE_PriceCutFloat = Float.valueOf(thisE_PriceCut).floatValue();
	
																	if (thisOneCutFloat == thisE_PriceCutFloat) {
																		priceTextualDiff_OKNumerically = true;
																	}
	
																	break;
																}
															}
														}
	
														if (!priceTextualDiff_OKNumerically) {
															val2 += "<br>"+thisOnePrint+" present";
															val1 += "<br>"+thisOnePrint+" not present";
															foundDiffs = true;
														}
													}
												}
												if (!foundDiffs) {
													val1 = "";
													val2 = ""; // to not show as a diff
												}
	
											}
										}
									}
	
									else if (thisClassID.equals(gc.attribute_CPS_VolumeForecast) || thisClassID.equals(gc.attribute_CPS_VolumeForecast) ||
											thisClassID.equals(gc.attribute_CPS_InformalValues) || thisClassID.equals(gc.attribute_CPS_DiscountValues)) {
	
										Vector expVolume = new Vector();
										if (!val1.equals(""))
											expVolume = texthelp.explode (val1, "^");
	
										Vector expVolume2 = new Vector();
										if (!val2.equals(""))
											expVolume2 = texthelp.explode (val2, "^");
	
										boolean anyDiff = false;
										if (!val1.equals(val2)) {
	
											val1 = "("+expVolume.size()+" periods)";
											val2 = "("+expVolume2.size()+" periods)";
	
											int maxmonths = expVolume.size();
											if (expVolume2.size()>maxmonths)
												maxmonths = expVolume2.size();
	
											for (int m=1; m<=maxmonths; m++) {
												int theIndex = m-1;
												String m1 = "";
												String m2 = "";
												if (theIndex<expVolume.size())
													m1 = (String)expVolume.get(theIndex);
												if (theIndex<expVolume2.size())
													m2 = (String)expVolume2.get(theIndex);
	
												m1 = texthelp.replaceAll(m1, ".", SESSnumberformat_decimal);
												m2 = texthelp.replaceAll(m2, ".", SESSnumberformat_decimal);
	
												if (!m1.equals(m2)) {
													anyDiff = true;
													val1 += "<br>"+m+": "+m1;
													val2 += "<br>"+m+": "+m2;
												}
											}
											if (!anyDiff) {
												val1="";
												val2="";
											}
										}
	
									}
									else if (thisClassID.equals(gc.attribute_CPS_Algorithm) || thisClassID.equals(gc.attribute_CPS_Algorithm_Reference) || thisClassID.equals(gc.attribute_CPS_Algorithm_Revision)) {
										val1 = texthelp.getMatchingAll_ReturnIndexVal (algorithmclasses, val1, 0, 3);
										val1 = texthelp.getField (val1, ":", 1);
										val2 = texthelp.getMatchingAll_ReturnIndexVal (algorithmclasses, val2, 0, 3);
										val2 = texthelp.getField (val2, ":", 1);
									}
	
									if (!val1.equals(val2)) {
	
										// double check that if there is padding of zeros or not.. on two floats.. i.e. 49.6 and 49.60
										boolean stillADiff = true;
										if (texthelp.isNumeric(val1) && texthelp.isNumeric(val2)) {
											float thisVal1Float = Float.valueOf(val1).floatValue();
											float thisVal2Float = Float.valueOf(val2).floatValue();
											if (thisVal1Float == thisVal2Float)
												stillADiff = false;
										}
	
										if (stillADiff) {
	
											if (!lastCountry.equals(thisCID))
												ret.add (texthelp.getVectorForItems(flagImage, thisCountryName, "", "", "", "", "" , thisCID));
	
											lastCountry = thisCID;
	
											if (subsetCountries) {  // hiding some items from countries this user cannot see..
												if (!countriesCanView.contains(thisAbbrev)) {
													val1 = "-not shown-";
													val2 = "-not shown-";
												}
											}
	
											if (thisClassID.equals(gc.attribute_CPS_Events) && compareOfPlanToCountryAttributes) {
												String hlpTxt = "Note: Only recurring calendar events at country level are compared for existence in the plan.  All other events of the plan are not deemed a difference, i.e. could have been purposefully added.   To mass add/trim reference events per the country settings visit the batch edit options of the Reference / Pricing events page of the plan.";
												thisName += " <a href=\"#\" data-html=\"true\" data-toggle=\"tooltip\" data-placement=\"auto top\" title=\""+texthelp.toolTipSafe(hlpTxt)+"\"><i class=\"fa fa-info-circle fa-lg\"></i></a>";
											}
											else if (thisClassID.equals(gc.attribute_CPS_RefBasket) && compareOfPlanToCountryAttributes) {
												String hlpTxt = "Note: The country settings reference baskets might be a superset of the plan reference baskets, since plan baskets are trimmed of countries not added to plan.  Only the countries of the plan are used in comparison to the higher level country settings basket.";
												thisName += " <a href=\"#\" data-html=\"true\" data-toggle=\"tooltip\" data-placement=\"auto top\" title=\""+texthelp.toolTipSafe(hlpTxt)+"\"><i class=\"fa fa-info-circle fa-lg\"></i></a>";
											}
	
											if (texthelp.isNumeric(val1))
												val1 = texthelp.replaceAll(val1, ".", SESSnumberformat_decimal);
											if (texthelp.isNumeric(val2))
												val2 = texthelp.replaceAll(val2, ".", SESSnumberformat_decimal);
	
	
											ret.add (texthelp.getVectorForItems("", "", thisName, val1, val2, thisClassID, thisSKUID, thisCID));
										}
									}
								}
							}
						}
					}
				}
			}
		}

		return ret;

	} // end getDiffsForLROCompare

	/**
	 * Return if a String contains a given set of special characters
	 *
	 * @param s (String):  the String
	 * @param check (String):  the characters to check
	 * @return boolean -  if numeric
	 */
	public static boolean containsSpecialChars(String s, String check)
	{
		boolean ret = false;
		for (int i = 0; i < check.length(); i++)
		{
			String thisChar = check.substring(i, i + 1);
			if (s.indexOf(thisChar) > -1)
			{
				ret = true;
				break;
			}
		}
		return ret;
	} // end containsSpecialChars


	/**
	 * Return if a list of items contains anything bad -- when expected are nothing but '', 'ALL', 'All' or numerics
	 *
	 * @param items (Vector):  list of items, nulls or strings
	 * @param listOfPerms (String):  perms list from the session, i.e. if 1540 exists, user is permitted
	 * @param strictlyNumbers (boolean):  whether the check allows some non-numerics.. like ALL, All, Closed from filter dropdowns
	 * @return boolean -  bad = true.. i.e. user should be halted
	 */
	public static boolean checkValuesBad_Scripting_Numerics(Vector items, Vector listOfPerms, boolean strictlyNumbers)
	{

		boolean ret = false;

		if (listOfPerms.contains ("1540"))  // class record for special admin override
			return ret;

		for (int i = 0; i < items.size(); i++) {
			String thisOne  = (String)items.get(i);
			if (thisOne != null) {
				thisOne = thisOne.trim();

				// if the value starts with a '-' (negative number, sometimes a fail safe for fetch against non-empty.. e.g. -999.. then peel off
				if (thisOne.startsWith ("-"))
					thisOne = thisOne.substring(1);

				if (!thisOne.equals("")) {

					if ((thisOne.equals("ALL") || thisOne.equals("All") || thisOne.equals("Closed"))) {  // OK when passed.. i.e. a filter dropdown with Closed or All, ALL in it.. is OK
						if (strictlyNumbers)
							ret = true;
					}
					else {
						if (thisOne.indexOf(" ")>-1)
							ret = true;

						if (!isOnlyNumbers(thisOne))
							ret = true;
					}

				}
			}
		}


		return ret;
	}


	/**
	 * Return if a list of items contains anything bad -- when expected are nothing but '', 'ALL', 'All' or numerics
	 *
	 * @param items (Vector):  list of items, nulls or strings
	 * @param listOfPerms (String):  perms list from the session, i.e. if 1540 exists, user is permitted
	 * @return boolean -  bad = true.. i.e. user should be halted
	 */

	public static boolean checkValuesBad_Scripting_Numerics(Vector items, Vector listOfPerms)
	{
		return checkValuesBad_Scripting_Numerics (items, listOfPerms, false);
	}

	/**
	 * Return if a list of items contains anything bad -- from input on forms - i.e. scripting attacks
	 *
	 * @param items (Vector):  the items to check
	 * @return boolean -  if found bad scripts
	 */
	public static boolean checkValuesBad_Scripting(Vector items)
	{
		return checkValuesBad_Scripting(items, new Vector());
	}

	/**
	 * Return if a list of items contains anything bad -- from input on forms - i.e. scripting attacks
	 *
	 * @param s (String):  the String
	 * @param check (String):  the characters to check
	 * @return boolean -  if numeric
	 */
	public static boolean checkValuesBad_Scripting(Vector items, Vector listOfPerms)
	{

		boolean ret = false;

		if (listOfPerms.contains ("1540"))  // class record for special admin override
			return ret;

		Vector listOfChecks = new Vector();

		listOfChecks.add ("<BODY>");
		listOfChecks.add ("</BODY>");
		listOfChecks.add ("<BODY ");
		listOfChecks.add ("</BODY ");
		listOfChecks.add ("<HTML>");
		listOfChecks.add ("</HTML>");
		listOfChecks.add ("<HTML ");
		listOfChecks.add ("</HTML ");
		listOfChecks.add ("<XML>");
		listOfChecks.add ("</XML>");
		listOfChecks.add ("<XML ");
		listOfChecks.add ("</XML ");
		listOfChecks.add ("<DIV>");
		listOfChecks.add ("</DIV>");
		listOfChecks.add ("<DIV ");
		listOfChecks.add ("</DIV ");
		listOfChecks.add ("ONLOAD=");
		listOfChecks.add ("ONFOCUS=");
		listOfChecks.add ("WINDOW[");
		listOfChecks.add ("'LOCATION'");
		listOfChecks.add (":URL(");
		listOfChecks.add (":URL (");
		listOfChecks.add ("<SCRIPT");
		listOfChecks.add ("</SCRIPT");
		listOfChecks.add ("<XML");
		listOfChecks.add ("<IMG");
		listOfChecks.add ("</XML");
		listOfChecks.add ("<XSS");
		listOfChecks.add ("</XSS");
		listOfChecks.add ("SP_EXECUTE");
		listOfChecks.add ("ALERT(");
		listOfChecks.add ("<IFRAME");
		listOfChecks.add ("<FRAME");
		listOfChecks.add ("ONERROR=");
		listOfChecks.add (" SRC=");
		listOfChecks.add ("/>");
		listOfChecks.add ("JAVASCRIPT:");
		listOfChecks.add ("\"JAVASCRIPT:");
		listOfChecks.add ("ONMOUSEOVER");
		listOfChecks.add ("WINDOW.OPEN");
		listOfChecks.add ("EXEC MASTER");
		listOfChecks.add ("XP_CMDSHELL");
		listOfChecks.add ("';");
		listOfChecks.add ("EVAL(");
		listOfChecks.add ("STYLE=");
		listOfChecks.add ("COLOR.EXPR");
		listOfChecks.add ("`;");
		listOfChecks.add ("SELECT @@");
		listOfChecks.add (" FROM DBA.");
		listOfChecks.add ("SELECT * FROM ");
		listOfChecks.add (" 1=1");
		listOfChecks.add ("A HREF");
		listOfChecks.add (":EXPRESSION");
		listOfChecks.add ("WAITFOR DELAY");
		listOfChecks.add (";DECLARE");
		listOfChecks.add ("EXEC(");
		listOfChecks.add ("CONTENT-LANGUAGE");
		listOfChecks.add ("CONTENT-ENCODING");
		listOfChecks.add ("CONTENT-LENGTH");
		listOfChecks.add ("CONTENT-RANGE");
		listOfChecks.add ("CONTENT-TYPE");
		listOfChecks.add ("<TEXTAREA>");
		listOfChecks.add ("</TEXTAREA>");

		listOfChecks.add ("&#");  // any HTML code.. not of normal &..


		// delim with ~~ means both in the find
		listOfChecks.add ("DELETE FROM ~~;");
		listOfChecks.add ("&lt;~~&gt;");
		listOfChecks.add ("[~~]");


		for (int i = 0; i < items.size(); i++) {
			String thisOne  = (String)items.get(i);
			if (thisOne != null) {
				String thisOneUpper = thisOne.toUpperCase();


				String thisOneUpperUnescapeHTML = StringEscapeUtils.unescapeHtml4(thisOneUpper);
				String thisOneUpperUnescapeHTML3 = StringEscapeUtils.unescapeHtml3(thisOneUpper);
				String thisOneUpperUnescapeXML = StringEscapeUtils.unescapeXml(thisOneUpper);

				String thisOneURLDecode = "";
				try {
					thisOneURLDecode = URLDecoder.decode(thisOneUpper, "UTF-8");
				}
				catch (Exception e)
				{
					// ok here..
				} // end catch



				for (int j=0; j<listOfChecks.size(); j++) {
					String thisCheck = (String)listOfChecks.get(j);
					if (thisCheck.indexOf("~~")>-1) {
						String thisCheck1 = getField (thisCheck, "~~",1);
						String thisCheck2 = getField (thisCheck, "~~",2);
						if (
							(thisOneUpper.indexOf (thisCheck1)>-1 && thisOneUpper.indexOf (thisCheck2)>-1) ||
							(thisOneUpperUnescapeHTML.indexOf (thisCheck1)>-1 && thisOneUpperUnescapeHTML.indexOf (thisCheck2)>-1) ||
							(thisOneUpperUnescapeHTML3.indexOf (thisCheck1)>-1 && thisOneUpperUnescapeHTML3.indexOf (thisCheck2)>-1) ||
							(thisOneUpperUnescapeXML.indexOf (thisCheck1)>-1 && thisOneUpperUnescapeXML.indexOf (thisCheck2)>-1) ||
							(thisOneURLDecode.indexOf (thisCheck1)>-1 && thisOneURLDecode.indexOf (thisCheck2)>-1)
							) {
							ret = true;
							break;
						}
					}
					else {
						if (
							thisOneUpper.indexOf (thisCheck)>-1 ||
							thisOneUpperUnescapeHTML.indexOf (thisCheck)>-1 ||
							thisOneUpperUnescapeHTML3.indexOf (thisCheck)>-1 ||
							thisOneUpperUnescapeXML.indexOf (thisCheck)>-1 ||
							thisOneURLDecode.indexOf (thisCheck)>-1
							) {
							ret = true;
							break;
						}
					}
				}
			}
		}
		return ret;
	} // end checkValuesBad_Scripting


	/**
	 * Return if a list of items contains anything bad -- from input on forms - i.e. scripting attacks
	 *
	 * @param value (String):  value used , i.e. 'col 1'
	 * @param check (String):  the characters to check
	 * @return boolean -  if numeric
	 */
	public static boolean checkSortColValueOK(String value)
	{

		boolean ret = true;

		// verify that sort columns (not gz'ed).. are of proper format.   JSP would get a true, and use default in cases of bad ones
		if (!value.startsWith ("col"))
			ret = false;
		else {
			String checkRest = replaceAll (value, " ", "");
			checkRest = replaceAll (checkRest, "col", "");
			checkRest = replaceAll (checkRest, "DESC", "");
			checkRest = replaceAll (checkRest, "ASC", "");
			if (!isOnlyNumbers (checkRest) && !checkRest.equals(""))
				ret = false;
		}

		return ret;
	} // end checkSortColValueOK

	/**
	 * Return if a String is longer bytes wise
	 *
	 * @param s (String):  the String
	 * @param maxLength (String):  max length to check against
	 * @return boolean -  if longer than  ( > )
	 */
	public static boolean checkLargerLengthBytes(String s, int leng)
	{
		boolean ret = false;
		try
		{
			byte[] check = s.getBytes("utf-8");
			if (check.length > leng)
				ret = true;
		}
		catch (Exception e)
		{
			// wrong here.. should return a true to be safe
			if (s.length() > leng)
				ret = true;
		} // end catch

		return ret;
	} // end checkLargerLengthBytes



	/**
	 * Return if a line from a SAS log is considered an error
	 *
	 * @param theLine (String):  the line from the log
	 * @return boolean -  if line is considered an error
	 */
	public static boolean lroLogFileLineHasError(String theLine)
	{
		boolean ret = false;

		String thisLineUpper = theLine.toUpperCase();

		if (thisLineUpper.indexOf("ERROR")>-1
				&& thisLineUpper.indexOf("ERROR DETECTION MACRO")==-1
				&& thisLineUpper.indexOf("ERRORABEND")==-1
				&& thisLineUpper.indexOf(".ERROR_CODE")==-1
				&& thisLineUpper.indexOf("_ERROR_")==-1
				) {  // hopefully above is not too broad

			ret = true;
		}


		return ret;
	} // end lroLogFileLineHasError


	/**
	 * Return if a String is OK an an email.. has a @, no spaces, no bad chars..
	 *
	 * @param s (String):  the String
	 * @return boolean -  if numeric
	 */
	public static boolean emailValueOK(String s)
	{
		boolean ret = true;
		Vector<String> explodeit = explode(s, ",");
		for (int e = 0; e < explodeit.size(); e++)
		{
			String thisE = (String) explodeit.get(e);
			thisE = thisE.trim();
			if (thisE.equals("") || thisE.indexOf(" ")>-1 || texthelp.containsSpecialChars(thisE, specialCharsEmail) || thisE.indexOf("@") == -1

			)
				ret = false;
		}
		return ret;
	} // end emailValueOK

	/**
	 * Return if a String is only numbers
	 *
	 * @param s (String):  the String
	 * @return boolean -  if numeric
	 */
	public static boolean isOnlyNumbers(String s)
	{
		boolean ret = true;
		if (s.equals(""))
			ret = false;
		else
		{
			Vector<String> numerics = new Vector<String>();
			for (int i = 0; i <= 9; i++)
			{
				numerics.add(String.valueOf(i));
			}
			for (int i = 0; i < s.length(); i++)
			{
				String sub = s.substring(i, i + 1);
				if (!numerics.contains(sub))
				{
					ret = false;
					break;
				}
			}
		}
		return ret;
	} // end isOnlyNumbers

	/**
	 * Return 'FROM DUAL' statement .. used in base SELECT queries from ORacle (only, not postgres)
	 *
	 * @param s (String):  the raw value
	 * @return String - the value for the SQL function syntax
	 */
	public static String getFromDualDBSyntax() {
		String ret = "";
		if (gc.dbType.equals("ORACLE"))
			ret = " FROM DUAL";
		return ret;
	} // end getFromDualDBSyntax

	/**
	 * Return the syntax used to get the current time via the database (GMT, Oracle set to DB timezone)
	 *
	 * @param s (String):  the raw value
	 * @return String - the full date time - ISO
	 */
	public static String getNowSQLSyntax() {
		String ret = "???? UNKNOWN DB TYPE ????";
		if (gc.dbType.equals("ORACLE"))
			ret = "SELECT to_char((systimestamp AT TIME ZONE 'UTC'), 'YYYY-MM-DD HH24:MI:SS') FROM dual";
		else if (gc.dbType.equals("POSTGRES"))
			ret = "SELECT to_char((CURRENT_TIMESTAMP AT TIME ZONE 'UTC'), 'YYYY-MM-DD HH24:MI:SS')";
		return ret;
	} // end getNowSQLSyntax

	/**
	 * Return the syntax for now, relative to DB insert/update statement
	 *
	 * @param s (String):  the raw value
	 * @return String - the date - ISO
	 */
	public static String getNowSQLForColumn() {
		String ret = "???? UNKNOWN DB TYPE ????";
		if (gc.dbType.equals("ORACLE"))
			ret = "(systimestamp AT TIME ZONE 'UTC')";
		else if (gc.dbType.equals("POSTGRES"))
			ret = "(CURRENT_TIMESTAMP AT TIME ZONE 'UTC')";

		return ret;
	} // end getNowSQLForColumn


	/**
	 * Return the syntax for DB fetch of a date column, returing ISO datetime
	 *
	 * @param columnname (String):  the column name
	 * @return String - the syntax DB expects for getting a timestamp to ISO
	 */
	public static String getDTColumnFetchSyntaxToISO(String columnname) {
		String ret = "???? UNKNOWN DB TYPE ????";
		if (gc.dbType.equals("ORACLE"))
			ret = "to_char("+columnname+",'YYYY-MM-DD HH24:MI:SS')";
		else if (gc.dbType.equals("POSTGRES"))
			ret = "to_char("+columnname+",'YYYY-MM-DD HH24:MI:SS')";
		return ret;
	} // end getDTColumnFetchSyntaxToISO

	/**
	 * Return the syntax for DB fetch of a date column, returing ISO date (just date)
	 *
	 * @param columnname (String):  the column name
	 * @return String - the syntax DB expects for getting a date to ISO
	 */
	public static String getDTColumnFetchSyntaxToISO_JustDate(String columnname) {
		String ret = "???? UNKNOWN DB TYPE ????";
		if (gc.dbType.equals("ORACLE"))
			ret = "to_char("+columnname+",'YYYY-MM-DD')";
		else if (gc.dbType.equals("POSTGRES"))
			ret = "to_char("+columnname+",'YYYY-MM-DD')";
		return ret;
	} // end getDTColumnFetchSyntaxToISO_JustDate

	/**
	 * Return the syntax for DB fetch of a now (DB time) with an interval of Days for it
	 *
	 * @param days (String):  the days interval (negative or positive)
	 * @return String - the syntax DB expects for getting the value
	 */
	public static String getNowSQLForColumn_WithIntervalDays(String days) {
		String ret = "???? UNKNOWN DB TYPE ????";
		if (gc.dbType.equals("ORACLE")) {
			if (days.startsWith("-"))
				ret = "to_char((systimestamp AT TIME ZONE 'UTC')"+days+", 'YYYY-MM-DD HH24:MI:SS')";
			else
				ret = "to_char((systimestamp AT TIME ZONE 'UTC')+"+days+", 'YYYY-MM-DD HH24:MI:SS')";
		}
		else if (gc.dbType.equals("POSTGRES")) {
			if (days.startsWith("-")) {
				days = replaceAll(days, "-", "");
				ret = "to_char((CURRENT_TIMESTAMP AT TIME ZONE 'UTC')-'"+days+" days'::interval, 'YYYY-MM-DD HH24:MI:SS')";
			}
			else
				ret = "to_char((CURRENT_TIMESTAMP AT TIME ZONE 'UTC')+'"+days+" days'::interval, 'YYYY-MM-DD HH24:MI:SS')";
		}

		return ret;
	} // end getNowSQLForColumn_WithIntervalDays


	/**
	 * Return the syntax for DB fetch of a now (DB time) with an interval of minutes for it
	 *
	 * @param minutes (String):  the minutes interval (negative or positive)
	 * @return String - the syntax DB expects for getting the value
	 */
	public static String getNowSQLForColumn_WithIntervalMinutes(String minutes) {
		String ret = "???? UNKNOWN DB TYPE ????";
		if (gc.dbType.equals("ORACLE")) {
			if (minutes.startsWith("-"))
				ret = "to_char((systimestamp AT TIME ZONE 'UTC')"+minutes+"/1440, 'YYYY-MM-DD HH24:MI:SS')";
			else
				ret = "to_char((systimestamp AT TIME ZONE 'UTC')+"+minutes+"/1440, 'YYYY-MM-DD HH24:MI:SS')";
		}
		else if (gc.dbType.equals("POSTGRES")) {
			if (minutes.startsWith("-")) {
				minutes = replaceAll(minutes, "-", "");
				ret = "to_char((CURRENT_TIMESTAMP AT TIME ZONE 'UTC')-'"+minutes+" minutes'::interval, 'YYYY-MM-DD HH24:MI:SS')";
			}
			else
				ret = "to_char((CURRENT_TIMESTAMP AT TIME ZONE 'UTC')+'"+minutes+" minutes'::interval, 'YYYY-MM-DD HH24:MI:SS')";
		}

		return ret;
	} // end getNowSQLForColumn_WithIntervalMinutes

	/**
	 * Return concatenate syntax
	 *
	 * @return String - the syntax
	 */
	public static String getDBSyntax_Concatenate(Vector concatlist) {
		String ret = "";
		if (gc.dbType.equals("ORACLE")) {
			for (int i=0; i<concatlist.size(); i++) {
				if (i==0)
					ret = (String)concatlist.get(i);
				else
					ret += "||"+(String)concatlist.get(i);
			}
		}
		else if (gc.dbType.equals("POSTGRES")) {
			for (int i=0; i<concatlist.size(); i++) {
				if (i==0)
					ret = (String)concatlist.get(i);
				else
					ret += "||"+(String)concatlist.get(i);
			}
		}
		return ret;
	} // end getDBSyntax_Concatenate


	/**
	 * Return the syntax for DB to_date or to_timestamp
	 *
	 * @return String - the syntax DB expects
	 */
	public static String getToDateSyntax(String value) {
		String ret = "???? UNKNOWN DB TYPE ????";
		if (gc.dbType.equals("ORACLE"))
			ret = "to_date('"+value+"','YYYY-MM-DD HH24:MI:SS')";
		else if (gc.dbType.equals("POSTGRES"))
			ret = "to_timestamp('"+value+"','YYYY-MM-DD HH24:MI:SS')";
		return ret;
	} // end getToDateSyntax

	/**
	 * Return the syntax for DB to_date
	 *
	 * @return String - the syntax DB expects
	 */
	public static String getToDateSyntax_JustDate(String value) {
		String ret = "???? UNKNOWN DB TYPE ????";
		if (gc.dbType.equals("ORACLE"))
			ret = "to_date('"+value+"','YYYY-MM-DD')";
		else if (gc.dbType.equals("POSTGRES"))
			ret = "to_date('"+value+"','YYYY-MM-DD')";
		return ret;
	} // end getToDateSyntax_JustDate


	/**
	 * Return a string that is converted to be filename safe
	 *
	 * @param s (String):  the String
	 * @return String - the converted file name
	 */
	public static String fileNameSafe(String s)
	{
		String ret = s;
		ret = replaceAll(ret, " ", "_");
		ret = replaceAll(ret, ":", "_");
		ret = replaceAll(ret, "&", "_");
		ret = replaceAll(ret, "(", "_");
		ret = replaceAll(ret, ")", "_");
		ret = replaceAll(ret, "^", "_");
		ret = replaceAll(ret, "#", "_");
		ret = replaceAll(ret, "?", "_");
		ret = replaceAll(ret, ".", "_");
		ret = replaceAll(ret, ";", "_");
		ret = replaceAll(ret, "/", "_");
		ret = replaceAll(ret, "\\", "_");
		return ret;
	} // end fileNameSafe

	/**
	 * Return a string that is &nbsp; when empty
	 *
	 * @param s (String):  the String
	 * @return String - the converted string
	 */
	public static String padHTMLSpace(String s)
	{
		if (s == null || s.trim().equals(""))
			return "&nbsp;";
		else
			return s.trim();
	} // end padHTMLSpace


	/**
	 * Return a string that pads a number of zeros to front of value
	 *
	 * @param s (String):  the String
	 * @param sizeMin (String):  the size, minimum of the string on return.  If less than this, 0's padded to front
	 * @return String - if empty, empty returned.  Otherwise the same string with any necessary padded zeros
	 */
	public static String padLeadingZeros(String s, int sizeMin)
	{
		if (s == null || s.trim().equals(""))
			return "";
		
		s = s.trim();

		if (s.length()<sizeMin) {
			s = replicate("0", sizeMin-s.length()) + s;
		}


		return s;
	} // end padLeadingZeros

	/**
	* Return a string converted to tool tip safe
	*
	* @param s (String):  the String
	* @return String - converted string
	*/
	public static String toolTipSafe(String s)
	{
		return toolTipSafe(s,new Vector());
	}

	/**
	* Return a string converted to tool tip safe - skip scripting checks, only if it contains no user provided data
	*
	* @param s (String):  the String
	* @param skipCheck (boolean):  Set true if skipping scripting check
	* @return String - converted string
	*/
	public static String toolTipSafe(String s, boolean skipCheck)
	{
		String ret = s;

		// javascript breaks on line breaks.. must explode and put as separate with + in between
		String newret = "";
		for (int i = 0; i < ret.length(); i++)
		{
			String thisChar = s.substring(i, i + 1);
			char thisChr = s.charAt(i);
			if (thisChr == 13) // for new lines that come in carriage return and newline together
				continue;
			else
				newret += thisChar;

		}

		ret = newret;
		
		ret = replaceAll(ret, "'", "&acute;");
		ret = replaceAll(ret, "<", "&lt;");
		ret = replaceAll(ret, ">", "&gt;");
		ret = replaceAll(ret, "\"", "&quot;");
		ret = ret.replaceAll("'", "\\\\'");
		

		return ret;
	} // end toolTipSafe
	/**
	* Return a string converted to tool tip safe
	*
	* @param s (String):  the String
	* @param skipItems (Vector):  Vector of potential scripting items that should be ignored in check (i.e. [DEV] like in role on full name)
	* @return String - converted string
	*/
	public static String toolTipSafe(String s, Vector skipItems)
	{
		String ret = s;

		// javascript breaks on line breaks.. must explode and put as separate with + in between
		String newret = "";
		for (int i = 0; i < ret.length(); i++)
		{
			String thisChar = s.substring(i, i + 1);
			char thisChr = s.charAt(i);
			if (thisChr == 13) // for new lines that come in carriage return and newline together
				continue;
			else
				newret += thisChar;

		}

		ret = newret;
		
		String tempRet = ret;
		
		for (int i = 0; i<skipItems.size(); i++) {
			tempRet = replaceAll(tempRet, (String)skipItems.get(i), "");
		}

		Vector noperms = new Vector();
		Vector theItemsCheck = getVectorForItems (tempRet);
		if (checkValuesBad_Scripting (theItemsCheck, noperms))
			ret = "(value cannot be displayed)";
		else {
			ret = replaceAll(ret, "'", "&acute;");
			ret = replaceAll(ret, "<", "&lt;");
			ret = replaceAll(ret, ">", "&gt;");
			ret = replaceAll(ret, "\"", "&quot;");
			ret = ret.replaceAll("'", "\\\\'");
		}

		return ret;
	} // end toolTipSafe

	/**
	 * Return for null / not-null submits on forms.  If its a t or f submitted..maintain (i.e. hidden), otherwise non-null = t
	 *
	 * @param val (String):  the value submitted to the form
	 * @return String
	 */
	public static String getCheckBoxSubmitToDBValue(String val)
	{
		String ret = "";
		if (val == null)
			ret = "f";
		else if (val.equals("t") || val.equals("f"))
			ret = val;
		else
			ret = "t";
		return ret;
	} // end getCheckBoxSubmitToDBValue

	/**
	 * Return img HTML for a country abbreviation - i.e. image of flag
	 *
	 * @param countryabbrev (String):  countryabbrev
	 * @return String - empty or the img= html
	 */
	public static String getFlagDisplay(String countryabbrev)
	{
		String ret = "";

		countryabbrev = countryabbrev.toLowerCase();

		if(countryabbrev.equalsIgnoreCase("UK"))
			countryabbrev = "gb";

		ret = "<span class=\"flag-icon flag-icon-" + countryabbrev + "\"></span>";


		return ret;
	} // end getFlagDisplay

	/**
 	 * Returns HTML text for JS charts
	 *
	 * @param sChart (String): HTML for just the chart
	 * @param tablewidth (String):  image of table that houses the image
	 * @return String - HTML for boxed image display
	 */
	public static String getBoxedJSChart(String sChart, String tablewidth)
	{
		String ret = "";

		ret+= "<table border=0 class=\"tableBoxed\" width=\""+tablewidth+"%\" style=\"border:none\">";
	
		ret+= "<tr><td class=\"THCellChart\" valign=\"top\" align=\"right\" style=\"text-align:left\">";
		ret+= sChart;
		ret+= "</td></tr></table>";

		return ret;
	} // end getBoxedJSChart

	/**
	 * Return comma of a string
	 *
	 * @param s (String):  the String
	 * @return String - the string in comma formatting
	 */
	public static String toCommaFormat(String s, boolean shortversion, String numberformat)
	{
		String ret = s;
		if (isNumeric(ret) && !ret.equals(""))
		{

			boolean isNeg = false;
			if (ret.indexOf("-") > -1)
			{
				isNeg = true;
				ret = replaceAll(ret, "-", "");
			}

			String build = "";
			int startPos = ret.length() - 1;
			if (ret.indexOf(".") > -1)
			{
				build = "." + getField(ret, ".", 2);
				startPos = ret.indexOf(".") - 1;
			}
			else
			{
				if (!shortversion)
					build = ".00";
			}

			int countcomma = 0;
			for (int j = startPos; j >= 0; j--)
			{
				String thisS = ret.substring(j, j + 1);
				if (countcomma == 3)
				{
					build = thisS + "," + build;
					countcomma = 0;
				}
				else
					build = thisS + build;

				if (!thisS.equals("-"))
					countcomma++;
			}
			ret = build;

			if (isNeg)
				ret = "(" + ret + ")";

			if (!numberformat.equals("")) {

				String hundreds = numberformat.substring(3,4);
				String decimal = numberformat.substring(11,12);

				if (ret.indexOf(".")>-1) {
					String left = texthelp.getField (ret, ".", 1);
					String right = texthelp.getField (ret, ".", 2);

					ret = texthelp.replaceAll(left, ",", hundreds) + decimal + right;
				}
				else {
					ret = texthelp.replaceAll(ret, ",", hundreds);
				}
			}

		}
		return ret;
	} // end toCommaFormat

	/**
	 * Return all but the dollar formatting on a value..
	 *
	 * @param s (String):  the String
	 * @return String - the string without dollar formatting
	 */
	public static String toDollarFormattingNoCents(String s, String numberformat, String currencysymbol)
	{
		String ret = s;

		if (s.indexOf(".")>-1)
			s = texthelp.getField(s, ".", 1);

		if (s.equals(""))
			ret = s;
		else if (s.length()<=3)
			ret = "$"+s;
		else if (s.length()==4)
			ret = "$"+s.substring(0,1)+ ","+s.substring (1);
		else if (s.length()==5)
			ret = "$"+s.substring(0,2)+ ","+s.substring (2);
		else if (s.length()==6)
			ret = "$"+s.substring(0,3)+ ","+s.substring (3);
		else if (s.length()==7)
			ret = "$"+s.substring(0,1)+ ","+s.substring (1,4)+ ","+s.substring (4);
		else if (s.length()==8)
			ret = "$"+s.substring(0,2)+ ","+s.substring (2,5)+ ","+s.substring (5);
		else if (s.length()==9)
			ret = "$"+s.substring(0,3)+ ","+s.substring (3,6)+ ","+s.substring (6);
		else if (s.length()==10)
			ret = "$"+s.substring(0,1)+ ","+s.substring (1,4)+ ","+s.substring (4,7)+ ","+s.substring (7);
		else if (s.length()==11)
			ret = "$"+s.substring(0,2)+ ","+s.substring (2,5)+ ","+s.substring (5,8)+ ","+s.substring (8);
		else if (s.length()==12)
			ret = "$"+s.substring(0,3)+ ","+s.substring (3,6)+ ","+s.substring (6,9)+ ","+s.substring (9);


		if (!ret.equals("")) {

			if (!currencysymbol.equals(""))
				ret = texthelp.replaceAll(ret, "$", currencysymbol);

			if (!numberformat.equals("")) {
				String hundreds = numberformat.substring(3,4);

				ret = texthelp.replaceAll(ret, ",", hundreds);
			}

		}


		return ret;
	} // end toDollarFormattingNoCents

	/**
	 * Return dolar format of a string
	 *
	 * @param s (String):  the String
	 * @return String - the string in dollar formatting
	 */
	public static String toDollarFormat(String s, String numberformat, String currencysymbol)
	{
		String ret = toDollarFormat(s, false, numberformat, currencysymbol);
		return ret;
	} // end toDollarFormat

	/**
	 * Return dolar format of a string
	 *
	 * @param s (String):  the String
	 * @return String - the string in dollar formatting
	 */
	public static String toDollarFormat(String s, boolean shortversion, String numberformat, String currencysymbol)
	{
		String ret = s;
		if (isNumeric(ret) && !ret.equals(""))
		{

			boolean isNeg = false;
			if (ret.indexOf("-") > -1)
			{
				isNeg = true;
				ret = replaceAll(ret, "-", "");
			}

			String build = "";
			int startPos = ret.length() - 1;
			if (ret.indexOf(".") > -1)
			{
				build = "." + getField(ret, ".", 2);
				startPos = ret.indexOf(".") - 1;
			}
			else
			{
				if (!shortversion)
					build = ".00";
			}

			int countcomma = 0;
			for (int j = startPos; j >= 0; j--)
			{
				String thisS = ret.substring(j, j + 1);
				if (countcomma == 3)
				{
					build = thisS + "," + build;
					countcomma = 0;
				}
				else
					build = thisS + build;

				if (!thisS.equals("-"))
					countcomma++;
			}
			ret = build;

			if (isNeg)
				ret = "(" + ret + ")";

		}
		if (!ret.equals("")) {
			ret = "$ " + ret;

			if (!currencysymbol.equals(""))
				ret = texthelp.replaceAll(ret, "$", currencysymbol);

			if (!numberformat.equals("")) {
				String hundreds = numberformat.substring(3,4);
				String decimal = numberformat.substring(11,12);

				if (ret.indexOf(".")>-1) {
					String left = texthelp.getField (ret, ".", 1);
					String right = texthelp.getField (ret, ".", 2);

					ret = texthelp.replaceAll(left, ",", hundreds) + decimal + right;
				}
				else {
					ret = texthelp.replaceAll(ret, ",", hundreds);
				}
			}

		}
		return ret;
	} // end toDollarFormat


	/**
	 * Return the HMTL needed for a table displaying an error - with no session area
	 *
	 * @param errortext (String):  text to display
	 * @return String - error table
	 */
	public static String getErrorShowNoSess(String errortext)
	{
		String ret = "<p class=\"errorText\">" + errortext + "</p>";
		return ret;
	} // end getErrorShow

	/**
	 * Return the HMTL needed for a table displaying an error
	 *
	 * @param errortext (String):  text to display
	 * @param tableWidthPerc (String):  table width (percentage)
	 * @return String - error table
	 */
	public static String getErrorShow(String errortext, String tableWidthPerc)
	{
		String ret = "<table border=0 width=\"" + tableWidthPerc + "%\"><tr><td align=\"left\"><font color=\"red\"><b>" + errortext + "</b></font></td></tr></table>";
		return ret;
	} // end getErrorShow


	/**
	 * Return the HMTL needed for a table displaying a message (percentage)
	 *
	 * @param messagetext (String):  text to display
	 * @param tablewidth (String):  table width (percentage)
	 * @return String - message table
	 */
	public static String getMessageShow(String messagetext, String tablewidth)
	{
		String ret = "<table border=0 width=\"" + tablewidth + "%\"><tr><td class=\"BlankCellL\"><b>" + messagetext + "</b></td></tr></table>";
		return ret;
	} // end getMessageShow

	/**
	 * Return the HMTL needed for a table displaying a message (percentage)
	 *
	 * @param messagetext (String):  text to display
	 * @param tablewidth (String):  table width (percentage)
	 * @return String - message table
	 */
	public static String getWarningShow(String messagetext, String tablewidth)
	{
		String ret = "<table border=0 width=\"" + tablewidth + "%\"><tr><td class=\"BlankCellL MessageWarnText\"><b>" + messagetext + "</b></td></tr></table>";
		return ret;
	} // end getWarningShow
	/**
	 * Replicate a string a certain number of times
	 *
	 * @param s (String) : string to replicate
	 * @param numbertimes (int):  number of replicates
	 * @return String - the resulting string
	 */
	private static String replicate(String s, int numbertimes)
	{
		String ret = "";
		for (int i = 1; i <= numbertimes; i++)
		{
			ret += s;
		}
		return ret;
	} // end replicate

	/**
	 * Return if contains a numeric character
	 *
	 * @param s (String):  the String
	 * @return boolean -  if numeric
	 */
	public static boolean containsNumeric(String s)
	{
		boolean ret = false;
		for (int j = 0; j < s.length(); j++)
		{
			String check = s.substring(j, j + 1);
			boolean thisCheck = isNumeric(check);
			if (thisCheck)
			{
				ret = true;
				break;
			}
		}
		return ret;
	} // end containsNumeric

	/**
	 * Return if a String is  valid HH:MM 24 hour clock value
	 *
	 * @param s (String):  the String
	 * @return boolean -  if numeric
	 */
	public static boolean isTimeValueValid(String s)
	{
		boolean ret = true;
		if (s.equals("") || s.length() != 5 || s.indexOf(":") == -1)
			ret = false;
		else
		{
			String hour = getField(s, ":", 1);
			String minute = getField(s, ":", 2);
			if (!isOnlyNumbers(hour) || !isOnlyNumbers(minute) || hour.length() != 2 || minute.length() != 2)
				ret = false;
			else
			{
				int hourInt = Integer.valueOf(hour).intValue();
				int minuteInt = Integer.valueOf(minute).intValue();
				if (hourInt > 23 || minuteInt > 59)
					ret = false;
			}
		}
		return ret;
	} // end isTimeValueValid


	/**
	 * Return if a String is  valid HH:MM 24 hour clock value
	 *
	 * @param s (String):  the String
	 * @return boolean -  if numeric
	 */
	public static boolean isTimeFullValueValid(String s)
	{
		boolean ret = true;
		if (s.equals("") || s.length() != 8 || s.indexOf(":") == -1)
			ret = false;
		else
		{
			String hour = getField(s, ":", 1);
			String minute = getField(s, ":", 2);
			String sec = getField(s, ":", 3);
			if (!isOnlyNumbers(sec) || !isOnlyNumbers(hour) || !isOnlyNumbers(minute) || hour.length() != 2 || minute.length() != 2 || sec.length() != 2)
				ret = false;
			else
			{
				int hourInt = Integer.valueOf(hour).intValue();
				int minuteInt = Integer.valueOf(minute).intValue();
				int secInt = Integer.valueOf(sec).intValue();
				if (hourInt > 23 || minuteInt > 59 || secInt > 59)
					ret = false;
			}
		}
		return ret;
	} // end isTimeFullValueValid

	/**
	 * Return the parent folder from the last item in the string delimited by \ - then by /... if neither found, return the string itself
	 *
	 * @param theString (String): the string to walk
	 * @return String -  the conversion
	 */
	public static String getParentFolderFromFullPath(String theString)
	{
		String ret = "";
		if (theString.indexOf("\\") > -1)
			ret = replaceAll(theString, "\\", "/");
		else
			ret = theString;

		if (ret.indexOf("/") > -1) {
			Vector explodeIt = explode(ret,"/");
			ret = (String)explodeIt.get(explodeIt.size()-2);
		}

		return ret;
	} // end getFilenameFromPossibleFullPath

	/**
	 * Return the last item in the string delimited by \ - then by /... if neither found, return the string itself
	 *
	 * @param theString (String): the string to walk
	 * @return String -  the conversion
	 */
	public static String getFilenameFromPossibleFullPath(String theString)
	{
		String ret = "";
		if (theString.indexOf("\\") > -1)
		{
			ret = walkToDelimiter(theString, "\\", true);
		}
		else
			ret = theString;

		if (ret.indexOf("/") > -1)
		{
			ret = walkToDelimiter(ret, "/", true);
		}

		return ret;
	} // end getFilenameFromPossibleFullPath


	/**
	 * Return the path back,but stripped of the file name and the '/' seperator.. i.e. yields the parent directory
	 *
	 * @param theString (String): the string to walk
	 * @return String -  the conversion
	 */
	public static String getFolderPathForFileFullPath(String thePath)
	{

		String ret = "";

		String fileName = getFilenameFromPossibleFullPath (thePath);

		ret = thePath.substring(0, thePath.length()-fileName.length());

		if (ret.indexOf("/")>-1)
			ret = ret.substring(0, ret.length()-1);

		return ret;

	} // end getFolderPathForFileFullPath
	
	/**
	 * Return a string, after walking from a given delimiter
	 *
	 * @param theString (String): the string to walk
	 * @param theDelim (String): string to delimit with
	 * @param walkback (boolean): true to walk backward, false to walk forward
	 * @return String -  the conversion
	 */
	private static String walkToDelimiter(String theString, String theDelim, boolean walkback)
	{
		String ret = "";
		Vector<String> exploded = explode(theString, theDelim);
		if (exploded.size() > 0 && theString.indexOf(theDelim) > -1)
		{
			if (walkback)
				ret = exploded.get((exploded.size() - 1));
			else
				ret = exploded.get(0);
		}

		return ret;
	} // end walkToDelimiter


	/**
	 * Return sorted vector - from vector of vectors, assumes values at index are strings
	 *
	 * @param sort (Vector):  vector of strings to sort
	 * @param index (int):  the index of the column to sort by
	 * @param ascend (boolean):  which direction to sort
	 * @return Vector -  the sorted vector
	 */
	public static Vector<Vector<String>> sortVectorStringsOneIndexStringWise(Vector<Vector<String>> sort, int index, boolean ascend)
	{
		for (int i = 0; i < sort.size() - 1; i++)
		{
			for (int j = (i + 1); j < sort.size(); j++)
			{
				Vector<String> vI = sort.get(i);
				Vector<String> vJ = sort.get(j);
				String Icompare = vI.get(index);
				String Jcompare = vJ.get(index);
				if (ascend)
				{
					if (Icompare.compareTo(Jcompare) > 0)
					{
						sort.set(i, vJ);
						sort.set(j, vI);
					}
				}
				else
				{
					if (Icompare.compareTo(Jcompare) < 0)
					{
						sort.set(i, vJ);
						sort.set(j, vI);
					}
				}
			}
		}
		return sort;
	} // end sortVectorStringsOneIndexStringWise


	/**
	 * Return sorted vector - from vector of vectors, assumes values at indexes are strings
	 *
	 * @param sort (Vector):  vector of strings to sort
	 * @param index (int):  the index of the column to sort by
	 * @param index2 (int):  if tie on first index, secondary sort
	 * @param ascend (boolean):  which direction to sort
	 * @return Vector -  the sorted vector
	 */
	public static Vector<Vector<String>> sortVectorStringsTwoIndexStringWise(Vector<Vector<String>> sort, int index, int index2, boolean ascend)
	{
		for (int i = 0; i < sort.size() - 1; i++)
		{
			for (int j = (i + 1); j < sort.size(); j++)
			{
				Vector<String> vI = sort.get(i);
				Vector<String> vJ = sort.get(j);
				String Icompare = vI.get(index);
				String Jcompare = vJ.get(index);

				String Icompare2 = vI.get(index2);
				String Jcompare2 = vJ.get(index2);

				if (ascend)
				{
					if (Icompare.compareTo(Jcompare) > 0)
					{
						sort.set(i, vJ);
						sort.set(j, vI);
					}
					else if (Icompare.equals(Jcompare)) {

						if (Icompare2.compareTo(Jcompare2) > 0)
						{
							sort.set(i, vJ);
							sort.set(j, vI);
						}
					}
				}
				else
				{
					if (Icompare.compareTo(Jcompare) < 0)
					{
						sort.set(i, vJ);
						sort.set(j, vI);
					}
					else if (Icompare.equals(Jcompare)) {

						if (Icompare2.compareTo(Jcompare2) < 0)
						{
							sort.set(i, vJ);
							sort.set(j, vI);
						}
					}
				}
			}
		}
		return sort;
	} // end sortVectorStringsTwoIndexStringWise

	/**
	 * Return sorted vector - from vector of vectors, assumes values at index are NUMBERS
	 *
	 * @param sort (Vector):  vector of strings to sort
	 * @param index (int):  the index of the column to sort by
	 * @param ascend (boolean):  which direction to sort
	 * @return Vector -  the sorted vector
	 */
	public static Vector<Vector<String>> sortVectorStringsOneIndex(Vector<Vector<String>> sort, int index, boolean ascend)
	{
		for (int i = 0; i < sort.size() - 1; i++)
		{
			for (int j = (i + 1); j < sort.size(); j++)
			{
				Vector<String> vI = sort.get(i);
				Vector<String> vJ = sort.get(j);
				String Icompare = vI.get(index);
				String Jcompare = vJ.get(index);
				float IcompareFloat = Float.valueOf(Icompare).floatValue();
				float JcompareFloat = Float.valueOf(Jcompare).floatValue();
				if (ascend)
				{
					if (IcompareFloat > JcompareFloat)
					{
						sort.set(i, vJ);
						sort.set(j, vI);
					}
				}
				else
				{
					if (IcompareFloat < JcompareFloat)
					{
						sort.set(i, vJ);
						sort.set(j, vI);
					}
				}
			}
		}
		return sort;
	} // end sortVectorStringsOneIndex


	/**
	 * Return sorted vector - from vector of vectors, for numeric sort on a sub vector that has the real index in it for compare (Country attributes, etc
	 *
	 * @param sort (Vector):  vector of strings to sort
	 * @param index (int):  the index of the column to sort by
	 * @param ascend (boolean):  which direction to sort
	 * @return Vector -  the sorted vector
	 */
	public static Vector<Vector<String>> sortVectorStringsOneIndexAttDefsInSubVector(Vector<Vector<String>> sort, int subVectorIndex, int index, boolean ascend)
	{
		for (int i = 0; i < sort.size() - 1; i++)
		{
			for (int j = (i + 1); j < sort.size(); j++)
			{
				Vector vI = (Vector)sort.get(i);
				Vector vJ = (Vector)sort.get(j);

				Vector attI = (Vector)vI.get(subVectorIndex);
				Vector attJ = (Vector)vJ.get(subVectorIndex);

				String Icompare = (String)attI.get(index);
				String Jcompare = (String)attJ.get(index);

				Icompare = texthelp.getField (Icompare, "~~", 1);
				Jcompare = texthelp.getField (Jcompare, "~~", 1);

				if (ascend) {
					if (Icompare.equals(""))
						Icompare = "99999";
					if (Jcompare.equals(""))
						Jcompare = "99999";
				}
				else {
					if (Icompare.equals(""))
						Icompare = "-99999";
					if (Jcompare.equals(""))
						Jcompare = "-99999";					
				}
				float IcompareFloat = Float.valueOf(Icompare).floatValue();
				float JcompareFloat = Float.valueOf(Jcompare).floatValue();
				if (ascend)
				{
					if (IcompareFloat > JcompareFloat)
					{
						sort.set(i, vJ);
						sort.set(j, vI);
					}
				}
				else
				{
					if (IcompareFloat < JcompareFloat)
					{
						sort.set(i, vJ);
						sort.set(j, vI);
					}
				}
			}
		}
		return sort;
	} // end sortVectorStringsOneIndexAttDefsInSubVector

	/**
	 * Return sorted vector - vector of strings only
	 *
	 * @param sort (Vector):  vector of strings to sort
	 * @param ascend (boolean):  which direction to sort
	 * @return Vector -  the sorted vector
	 */
	public static Vector<String> sortStringVector(Vector<String> sort, boolean ascend)
	{
		for (int i = 0; i < sort.size() - 1; i++)
		{
			for (int j = (i + 1); j < sort.size(); j++)
			{
				String Icompare = sort.get(i);
				String Jcompare = sort.get(j);
				if (ascend)
				{
					if (Icompare.compareTo(Jcompare) > 0)
					{
						sort.set(i, Jcompare);
						sort.set(j, Icompare);
					}
				}
				else
				{
					if (Icompare.compareTo(Jcompare) < 0)
					{
						sort.set(i, Jcompare);
						sort.set(j, Icompare);
					}
				}
			}
		}
		return sort;
	} // end sortStringVector

	/**
	 * Return sorted vector - vector of numeric values only
	 *
	 * @param sort (Vector):  vector of strings to sort
	 * @param ascend (boolean):  which direction to sort
	 * @return Vector -  the sorted vector
	 */
	public static Vector<String> sortStringVectorOfNumbers(Vector<String> sort, boolean ascend)
	{
		for (int i = 0; i < sort.size() - 1; i++)
		{
			for (int j = (i + 1); j < sort.size(); j++)
			{
				String Icompare = sort.get(i);
				String Jcompare = sort.get(j);
				Integer IcompareInteger = Integer.valueOf(Icompare);
				Integer JcompareInteger = Integer.valueOf(Jcompare);
				if (ascend)
				{
					if (IcompareInteger.intValue() > JcompareInteger.intValue())
					{
						sort.set(i, Jcompare);
						sort.set(j, Icompare);
					}
				}
				else
				{
					if (IcompareInteger.intValue() < JcompareInteger.intValue())
					{
						sort.set(i, Jcompare);
						sort.set(j, Icompare);
					}
				}
			}
		}
		return sort;
	} // end sortStringVectorOfNumbers


	/**
	 * Return string with replaced spaces to %20's
	 *
	 * @param s (String):  string to alter
	 * @return String -  the altered string
	 */
	public static String replaceSpaces(String s)
	{
		return s.replaceAll(" ", "%20");
	}

	/**
	 * Replace all instances of a substring with another string
	 *
	 * @param s (String):  string to alter
	 * @param target (String):  substring targer
	 * @param changeto (String):  change to
	 * @return String -  the altered string
	 */
	public static String replaceAll(String s, String target, String changeto)
	{

		if (s == null || s.equals("") || target.equals(changeto))
			return s;

		Vector<String> v = explode(s, target, false);
		String ret = implode(v, changeto);

		return ret;
	}
	/**
	 * reverse of explode, turn vector to string
	 *
	 * @param toimplode (Vector):  vector of items to implode to string
	 * @param delimiter (String):  the delimiter that is used in the resulting string
	 * @return String -  imploded string
	 */
	public static String implode(Vector<String> toimplode, String delimiter)
	{
		StringBuilder ret = new StringBuilder();
		for (int i = 0; i < toimplode.size(); i++)
		{
			if (i == 0)
				ret.append(toimplode.get(i));
			else
				ret.append(delimiter + toimplode.get(i));
		}
		return ret.toString();
	} // end implode

	/**
	 * Return a vector of all parts of string - exploded with respect to passed delimiter
	 *
	 * @param s (String):  string to alter
	 * @param delim (String):  delimiter to use in explode
	 * @return Vector of strings -  each part - will return Vector of just the string if no delimter found
	 */
	public static Vector<String> explode(String s, String delim)
	{
		return explode(s, delim, false);
	}

	/**
	 * Return a vector of all parts of string - exploded with respect to passed delimiter
	 *
	 * @param s (String):  string to alter
	 * @param delim (String):  delimiter to use in explode
	 * @param doTrims (boolean):  trim the lines, and fields as it goes
	 * @return Vector of strings -  each part - will return Vector of just the string if no delimter found
	 */
	public static Vector<String> explode(String s, String delim, boolean doTrims)
	{
		Vector<String> ret = new Vector<String>();
		int index = 0;
		if (doTrims)
			s = s.trim();
		while (true)
		{
			index = s.indexOf(delim);
			if (index == -1)
			{
				if (doTrims)
					ret.add(s.trim());
				else
					ret.add(s);
				break;
			}
			else if (index == 0)
				ret.add("");
			else
			{
				if (doTrims)
				{
					String thisAdd = s.substring(0, index);
					thisAdd = thisAdd.trim();
					ret.add(thisAdd);
				}
				else
					ret.add(s.substring(0, index));
			}

			s = s.substring(index + delim.length());
		}

		return ret;
	}

	/**
	 * Get field inside a string with respect to passed delimiter
	 *
	 * @param s (String):  string to search
	 * @param delim (String):  the delimiter
	 * @param fieldnum (int):  the nth field to get - starts with 1!
	 * @return String -  full string if delimiter not found, otherwise the field, empty string if a field that is past the exploded values of the string
	 */
	public static String getField(String s, String delim, int fieldnum)
	{
		return getField (s, delim, fieldnum, false);
	} // end getField


	/**
	 * Get field inside a string with respect to passed delimiter
	 *
	 * @param s (String):  string to search
	 * @param delim (String):  the delimiter
	 * @param fieldnum (int):  the nth field to get - starts with 1!
	 * @return String -  full string if delimiter not found, otherwise the field, empty string if a field that is past the exploded values of the string
	 */
	public static String getField(String s, String delim, int fieldnum, boolean trim)
	{
		String ret = s;

		Vector<String> exploded = explode(s, delim);

		int index = s.indexOf(delim);

		if (exploded.size() == 1 && index > -1)
			ret = s;
		else
		{
			if (fieldnum > exploded.size())
				ret = "";
			else
				ret = exploded.get(fieldnum - 1);
		}

		if (trim)
			ret = ret.trim();

		return ret;
	} // end getField

	/**
	 * Replace all strange chars with lookup codes
	 *  CHANGES NEW LINE CHARS to <br>'s
	 *
	 * @param s (String):  string to alter
	 * @return String -  the altered string
	 */
	public static String fixAllHTML(String s)
	{
		String altered = s;
		altered = s.replaceAll("&", "&amp;");
		altered = altered.replaceAll(">", "&gt;");
		altered = altered.replaceAll("<", "&lt;");
		altered = altered.replaceAll("�", "&quot;");
		altered = altered.replaceAll("�", "&quot;");
		altered = altered.replaceAll("\"", "&quot;");
		altered = altered.replaceAll("\\\\", "&#92;");
		altered = altered.replaceAll("�", "&agrave;");
		altered = altered.replaceAll("�", "&Agrave;");
		altered = altered.replaceAll("�", "&acirc;");
		altered = altered.replaceAll("�", "&Acirc;");
		altered = altered.replaceAll("�", "&auml;");
		altered = altered.replaceAll("�", "&aring;");
		altered = altered.replaceAll("�", "&Aring;");
		altered = altered.replaceAll("�", "&aelig;");
		altered = altered.replaceAll("�", "&AElig;");
		altered = altered.replaceAll("�", "&ccedil;");
		altered = altered.replaceAll("�", "&Ccedil;");
		altered = altered.replaceAll("�", "&eacute;");
		altered = altered.replaceAll("�", "&Eacute;");
		altered = altered.replaceAll("�", "&egrave;");
		altered = altered.replaceAll("�", "&Egrave;");
		altered = altered.replaceAll("�", "&ecirc;");
		altered = altered.replaceAll("�", "&Ecirc;");
		altered = altered.replaceAll("�", "&euml;");
		altered = altered.replaceAll("�", "&Euml;");
		altered = altered.replaceAll("�", "&iuml;");
		altered = altered.replaceAll("�", "&Iuml;");
		altered = altered.replaceAll("�", "&ocirc;");
		altered = altered.replaceAll("�", "&Ocirc;");
		altered = altered.replaceAll("�", "&ouml;");
		altered = altered.replaceAll("�", "&Ouml;");
		altered = altered.replaceAll("�", "&oslash;");
		altered = altered.replaceAll("�", "&Oslash;");
		altered = altered.replaceAll("�", "&szlig;");
		altered = altered.replaceAll("�", "&ugrave;");
		altered = altered.replaceAll("�", "&Ugrave;");
		altered = altered.replaceAll("�", "&ucirc;");
		altered = altered.replaceAll("�", "&Ucirc;");
		altered = altered.replaceAll("�", "&uuml;");
		altered = altered.replaceAll("�", "&Uuml;");

		altered = altered.replaceAll("�", "&cent;");
		altered = altered.replaceAll("�", "&reg;");
		altered = altered.replaceAll("�", "&copy;");
		altered = altered.replaceAll("�", "&euro;");
		altered = altered.replaceAll("�", "&deg;");

		altered = altered.replaceAll("�", "&pound;");
		altered = altered.replaceAll("�", "&curren;");
		altered = altered.replaceAll("�", "&yen;");
		altered = altered.replaceAll("�", "&brvbar;");

		altered = altered.replaceAll("�", "&sect;");
		altered = altered.replaceAll("�", "&brvbar;");

		altered = altered.replaceAll("�", "&sup2;");
		altered = altered.replaceAll("�", "&sup3;");
		altered = altered.replaceAll("�", "&micro;");
		altered = altered.replaceAll("�", "&para;");
		altered = altered.replaceAll("�", "&frac14;");
		altered = altered.replaceAll("�", "&frac12;");
		altered = altered.replaceAll("�", "&frac34;");
		altered = altered.replaceAll("�", "&section;");
		altered = altered.replaceAll("�", "&trade;");

		return altered;
	} // end fixAllHTML


	/**
	 * Replace all chars for write to database
	 *
	 * @param s (String):  string to alter
	 * @return String -  the altered string
	 */
	public static String fixAll(String s)
	{
		String altered = s;
		altered = altered.replaceAll("'", "~SQUO~");
		altered = altered.replaceAll("�", "~SQUO~");
		altered = altered.replaceAll("�", "~SQUO~");
		altered = altered.replaceAll("`", "~SQUO~");

		return altered;
	} // end fixAll

	/**
	 * Return <br>'s to \r\n
	 *
	 * @param s (String):  string to alter
	 * @return String -  the lines to print in the textarea.
	 */
	public static String backToAllForTextArea(String s)
	{
		return backToAllForTextArea(s, true); // default is to HTML encode..
	}

	/**
	 * Return <br>'s to \r\n
	 *
	 * @param s (String):  string to alter
	 * @return String -  the lines to print in the textarea.
	 */
	public static String backToAllForTextArea(String s, boolean doWebPageEncode)
	{
		String altered = "";

		if (doWebPageEncode)
			altered = backToAllForWebPage(s);
		else
			altered = backToAll(s);

		altered = altered.replaceAll("<br>", "\n");
		return altered;
	}

	/**
	 * Return " with &quot; for inclusin in HTML text field
	 *
	 * @param s (String):  string to alter
	 * @return String -  the lines to print in the textarea.
	 */
	public static String backToAllForTextField(String s)
	{
		String altered = backToAll(s);
		// in case it was HTML encoded... undo that.. to have just double quotes done... (for placement in field)

		altered = StringEscapeUtils.unescapeHtml4(altered);


		altered = altered.replaceAll("\"", "&quot;");
		return altered;
	}

	/**
	 * Undo the fix All
	 *
	 * @param s (String):  string to alter
	 * @return String -  the altered string
	 */
	public static String backToAll(String s)
	{
		String altered = s;
		altered = altered.replaceAll("\\n", "<br>");
		altered = altered.replaceAll("~SQUO~", "'");
		return altered;
	} // end backToAll


	/**
	 * Undo the fix All - with HTML escaping
	 *
	 * @param s (String):  string to alter
	 * @return String -  the altered string
	 */
	public static String backToAllForWebPage(String s)
	{
		String altered = backToAll(s);
		altered = StringEscapeUtils.escapeHtml4(altered);

		altered = altered.replaceAll("&lt;br&gt;", "<br>"); // bring back any line returns or returns.. to true HTML return

		return altered;
	} // end backToAllForWebPage

	/**
	 * For plain text email, convert <br>'s to \n (new lines in email)
	 *
	 * @param s (String):  string to alter
	 * @return String -  the altered string
	 */
	public static String backToAllForEmail(String s)
	{
		String altered = backToAll(s);
		altered = altered.replaceAll("<br>", "\n");
		return altered;
	}

	/**
	 * For PDF formatting
	 *
	 * @param s (String):  string to alter
	 * @return String -  the altered string
	 */
	public static String backToAllForPDF(String s)
	{
		String altered = backToAll(s);

		// also replace chars that are HTML codes..

		altered = replaceAll(altered, "&gt;", ">");
		altered = replaceAll(altered, "&nbsp;", " ");
		altered = replaceAll(altered, "&lt;", "<");
		altered = replaceAll(altered, "&quot;", "\"");
		altered = altered.replaceAll("&amp;", "&");
		altered = altered.replaceAll("<br>", "\n");

		return altered;
	}

	/**
	 * Return the value from the field^value~field^value .. delimitation of user's othersettings string value
	 *
	 * @param othersettings (Vector):  the othersettings value for user
	 * @param field (String):  the field to find
	 * @return String - the value - if field is found, empty string if not found
	 */
	public static String getValueFromOtherSettings(String othersettings, String field)
	{
		String ret = "";
		Vector otherExp = explode (othersettings, "~~~~~");
		for (int i=0; i<otherExp.size(); i++) {
			String thisOne = (String)otherExp.get(i);
			String thisField = getField (thisOne, "=====", 1);
			if (thisField.equals(field)) {
				ret = getField (thisOne, "=====", 2);
				break;
			}
		}
		return ret;
	} // end getValueFromOtherSettings

	/**
	 * Return the value from the field^value~field^value .. delimitation of user's othersettings string value
	 *
	 * @param othersettings (Vector):  the othersettings value for user
	 * @param field (String):  the field to find
	 * @return String - the value - if field is found, empty string if not found
	 */
	public static String getModifiedOtherSettingsString(String othersettings, String field, String newvalue)
	{
		String ret = othersettings;

		if (othersettings.equals(""))
			ret = field+"====="+newvalue;
		else {

			ret = "";

			boolean foundIt = false;

			Vector otherExp = explode (othersettings, "~~~~~");
			for (int i=0; i<otherExp.size(); i++) {
				String thisOne = (String)otherExp.get(i);
				String thisField = getField (thisOne, "=====", 1);
				if (thisField.equals(field)) {
					foundIt = true;
					String newWrite = field+"====="+newvalue;
					if (ret.equals(""))
						ret = newWrite;
					else
						ret += "~~~~~"+newWrite;
				}
				else {
					if (ret.equals(""))
						ret = thisOne;
					else
						ret += "~~~~~"+thisOne;
				}
			}

			if (!foundIt)
				ret += "~~~~~"+field+"====="+newvalue;
		}
		return ret;
	} // end getModifiedOtherSettingsString


	/**
	 * Return the <option> choices with one selected
	 *
	 * @param choices (String[]):  the choices
	 * @param currentSelect (String):  the current selected item
	 * @return Vector of strings - choices
	 */
	public static Vector<String> getOptionPrints(String[] choices, String currentSelect)
	{
		Vector<String> ret = new Vector<String>();
		for (int i = 0; i < choices.length; i++)
		{
			String thisOne = choices[i];
			if (currentSelect.equals(thisOne))
				ret.add("<option selected>" + thisOne + "</option>");
			else
				ret.add("<option>" + thisOne + "</option>");
		}
		return ret;
	} // end getOptionPrints

	//naasse


	/**
	 * Return the HMTL needed for a sortable header - returns SortCellHXS style cells
	 *
	 * @param cols (String[][]):  two dim array - with each sub-array <Column name to display>,<col width>,<default sort> (ASC or DESC)  Use DefaultSort=nothing for a non clickable header
	 * @param url (String):  the url to jump to with the header sort links - should include any other passed parameters
	 * @param currentSort (String):  the current sort - of format 'colX ASC' or 'colX DESC'
	 * @return String -  the altered string
	 */
	// return the html for a sortable SortCellHXS header  - cols need to be array of arrays, with Col Header Text,Width, Default sort ASC or DESC


	public static Vector<String> getSortableHeader(String[][] cols, String url, String currentSort)
	{
		return getSortableHeader(cols, url, currentSort, false);	
	}

	public static Vector<String> getSortableHeader(String[][] cols, String url, String currentSort, boolean xSmall)
	{
		String nonSortCell = "SortCell";
		String nonSortCellCenter = "SortCellC";
		String activeSortCell = "SortCellH";
		
		if (xSmall) {
			nonSortCell+="XS";
			nonSortCellCenter+="XS";
			activeSortCell+="XS";
		}

		Vector<String> ret = new Vector<String>();
		ret.add("<tr>");
		for (int i = 1; i <= cols.length; i++)
		{
			String[] thisA = cols[i - 1];
			String thisHT = thisA[0];
			String thisW = thisA[1];
			String thisDef = thisA[2];
			String thisTitle = "";
			if (thisA.length>3)
				thisTitle = thisA[3];

			String thisStyleNonSort = nonSortCell;
			if (thisHT.indexOf("checkedAll")>-1)
				thisStyleNonSort = nonSortCellCenter;

			if (currentSort.indexOf("col" + i + " ") > -1)
			{
				if (currentSort.indexOf(" ASC")>-1)
					ret.add("<td class=\""+activeSortCell+"\" width=\"" + thisW + "%\"><i class=\"glyphicon glyphicon-chevron-up\" aria-hidden=\"true\"></i><a href=\"" + url + "&orderby=col" + (i) + "%20DESC\">" + thisHT + "</a></td>");
				else
					ret.add("<td class=\""+activeSortCell+"\" width=\"" + thisW + "%\"><i class=\"glyphicon glyphicon-chevron-down\" aria-hidden=\"true\"></i><a href=\"" + url + "&orderby=col" + (i) + "%20ASC\">" + thisHT + "</td>");
			}
			else if (!thisTitle.equals(""))
			{
				if (thisHT.equals(""))
					ret.add("<td class=\""+nonSortCell+"\" width=\"" + thisW + "%\">&nbsp;</td>");
				else if (thisDef.equals(""))
					ret.add("<td class=\""+nonSortCell+"\" width=\"" + thisW + "%\"><a title='" + thisTitle + "'>" + thisHT + "</a></td>");
				else
					ret.add("<td class=\""+nonSortCell+"\" width=\"" + thisW + "%\"><a title='" + thisTitle + "' href=\"" + url + "&orderby=col" + (i) + "%20" + thisDef + "\">" + thisHT + "</a></td>");
			}
			else {
				if (thisDef.equals(""))
					ret.add("<td class=\""+thisStyleNonSort+"\" width=\"" + thisW + "%\">" + thisHT + "</td>");
				else
					ret.add("<td class=\""+thisStyleNonSort+"\" width=\"" + thisW + "%\"><a href=\"" + url + "&orderby=col" + (i) + "%20" + thisDef + "\">" + thisHT + "</td>");
			}
		}
		ret.add("</tr>");
		return ret;
		
	}
	

	/**
	 * Prints to a daily debug log.
	 *
	 * @param obj (Object):  what to print to log
	 * @return String
	 */
	public static String debugPrint(Object obj)
	{
		String ret = "";
		debugPrint (obj, false);
		return ret;

	} // end debugPrint


	/**
	 * Prints to a daily debug log.
	 *
	 * @param obj (Object):  what to print to log
	 * @return String
	 */
	public static String debugPrint(Object obj, boolean includeDate)
	{
		String ret = "";
		logging.printDebug(obj, includeDate);
		return ret;

	} // end debugPrint

	/**
	 * Prints to a daily debug log.
	 *
	 * @param theInt (int):  int to bring
	 * @return String
	 */
	public static String debugPrint(int theInt)
	{
		String ret = "";
		logging.printDebug(theInt);

		return ret;

	} // end debugPrint

	/**
	 * Return 8 char password - random chars in first 7, with one upper, with 1 number at back
	 *
	 * @return String -  random password
	 */
	public static String getRandPassword()
	{
		char kCharsUpper[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
		char kChars[] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
		String ret = "";
		for (int i = 1; i <= 7; i++)
		{
			int index = (int) (Math.random() * 26);
			if (i == 1)
				ret += kCharsUpper[index];
			else
				ret += kChars[index];
		}
		int number = (int) (Math.random() * 10);
		ret += String.valueOf(number);
		return ret;
	} // end getRandPassword

	/**
	 * Return random text based on mode and length
	 *
	 * @return String -  random password
	 */
	public static String getRandText(String mode, int length)
	{
		char kCharsUpper[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
		char kChars[] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
		char kCharsNum[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
		String ret = "";

		if (mode.equals("") || mode.equals("ALPHA") || mode.equals("ALPHANUMERIC")) {

			for (int i = 1; i <= length; i++)
			{

				int randPick = 0;

				if (mode.equals("ALPHA"))
					randPick = (int) (Math.random() * 2);
				else if (mode.equals("ALPHANUMERIC"))
					randPick = (int) (Math.random() * 3);

				int index = (int) (Math.random() * 26);
				if (randPick == 2)
					index = (int) (Math.random() * 10);

				if (randPick == 0)
					ret += kCharsUpper[index];
				else if (randPick == 1)
					ret += kChars[index];
				else
					ret += kCharsNum[index];
			}
		}
		else
			ret = "ERROR: No matching case for rand text mode";

		return ret;
	} // end getRandText



	/**
	 * return random text, with a random length, of min to max length
	 *
	 * @return String -  random value (and length)
	 */
	public static String getRandTextLengthRand(String mode, int minlength, int maxlength)
	{
		int randPick = (int) (Math.random() * (maxlength-minlength+1));
		return getRandText (mode, randPick+minlength);

	} // end getRandTextLengthRand

	/**
	 * Return if contains a non alpha-numeric character
	 *
	 * @param s (String):  the String
	 * @return boolean -  if alpha
	 */
	public static boolean containsNonAlphaNumeric(String s)
	{
		char kChars[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
		boolean ret = false;
		for (int j = 0; j < s.length(); j++)
		{
			char check = s.charAt(j);
			boolean found = false;
			for (int i = 0; i < kChars.length; i++)
			{
				if (kChars[i] == check)
				{
					found = true;
					break;
				}
			}
			if (!found)
			{
				ret = true;
				break;
			}

		}
		return ret;
	} // end containsNonAlphaNumeric

	/**
	 * Return if contains an alpha character (upper case)
	 *
	 * @param s (String):  the String
	 * @return boolean -  if alpha
	 */
	public static boolean containsUpperAlpha(String s)
	{
		char kChars[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
		boolean ret = false;
		for (int j = 0; j < s.length(); j++)
		{
			char check = s.charAt(j);
			for (int i = 0; i < kChars.length; i++)
			{
				if (kChars[i] == check)
				{
					ret = true;
					break;
				}
			}
			if (ret)
				break;
		}
		return ret;
	} // end containsUpperAlpha

	/**
	 * Return if contains an alpha character (upper case)
	 *
	 * @param s (String):  the String
	 * @return boolean -  if alpha
	 */
	public static boolean containsLowerAlpha(String s)
	{
		char kChars[] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
		boolean ret = false;
		for (int j = 0; j < s.length(); j++)
		{
			char check = s.charAt(j);
			for (int i = 0; i < kChars.length; i++)
			{
				if (kChars[i] == check)
				{
					ret = true;
					break;
				}
			}
			if (ret)
				break;
		}
		return ret;
	} // end containsUpperAlpha



	/**
	 * Return a value from tag val delimitting on batch jobs.  Outer of ^^^, then Name~~~Value pairs
	 *
	 * @param f (float):  the float value
	 * @param unit (String):  the unit to display
	 * @return String - float size display with units
	 */
	public static String getBatchJobTagValValue(String raw, String name) {
		String ret = "";
		Vector exp = explode(raw, "^^^");
		for (int i=0; i<exp.size(); i++) {
			String thisOne = (String)exp.get(i);
			String theName = getField (thisOne, "~~~", 1);
			if (theName.equals(name)) {
				ret = getField(thisOne, "~~~", 2);
				break;
			}
		}
		return ret;
	} // end getBatchJobTagValValue



	/**
	 * Return a string from float - formatted to number of decimal places
	 *
	 * @param theVal (String):  the float value
	 * @param numdecimals (int):  # of decimal places
	 * @return String - formatted value (and rounded)
	 */
	public static String getFloatDisplayFormatted(String theVal, int numdecimals) {

		String ret = theVal;

		if (!ret.equals("") && isNumeric(ret)) {
			float retFloat = Float.valueOf(ret).floatValue();
			ret = getFloatDisplayFormatted(retFloat, numdecimals);
		}

		return ret;

	} // end getFloatDisplayFormatted


	/**
	 * Return a string from double - formatted to number of decimal places
	 *
	 * @param theVal (double):  the float value
	 * @param numdecimals (int):  # of decimal places
	 * @return String - formatted value (and rounded)
	 */
	public static String getFloatDisplayFormatted(double theVal, int numdecimals) {

		String ret = "";

		String places = "";
		for (int i=1; i<=numdecimals; i++) {
			places += "0";
		}

		DecimalFormat df = new DecimalFormat("#."+places);
		ret = df.format(theVal);

		if (ret.startsWith("."))
			ret = "0"+ret;

		return ret;

	} // end getFloatDisplayFormatted


	/**
	 * Return a string from float - formatted to number of decimal places
	 *
	 * @param theVal (float):  the float value
	 * @param numdecimals (int):  # of decimal places
	 * @return String - formatted value (and rounded)
	 */
	public static String getFloatDisplayFormatted(float theVal, int numdecimals) {

		String ret = "";

		String places = "";
		for (int i=1; i<=numdecimals; i++) {
			places += "0";
		}

		DecimalFormat df = new DecimalFormat("#."+places);
		ret = df.format(theVal);

		if (ret.startsWith("."))
			ret = "0"+ret;

		return ret;

	} // end getFloatDisplayFormatted

	/**
	 * Return a display for size of file/dir.. i.e. GBs, MBs, that rounds the float for display
	 *
	 * @param sizeTotalBytes (float):  the float value (in bytes)
	 * @param unit (String):  the unit to display
	 * @return String - float size display
	 */
	public static String getFloatSizeDisplayFromBytes(float sizeTotalBytes, String unit, boolean includeUnit) {

		float sizeTotal = sizeTotalBytes;

		if (sizeTotal >= 1073741824 && unit.equals("MB"))
			unit = "GB";

		if (unit.equals("GB"))
			sizeTotal = sizeTotal / 1073741824;
		else if (unit.equals("MB"))
			sizeTotal = sizeTotal / 1048576;

		String ret = String.valueOf(sizeTotal);

		if (ret.indexOf("E-")>-1) { // very small ..
			ret = "0.000";
			if (includeUnit)
				ret = "less than 1 " +unit;
		}
		else {

			String secondpart = getField (ret, ".", 2);
			if (secondpart.length()>2) {
					secondpart = secondpart.substring(0,3);
			}

			ret = getField (ret, ".", 1) + "."+ secondpart;
			if (includeUnit)
				 ret += " "+unit;
		}

		return ret;
	} // end getFloatSizeDisplayFromBytes



	/**
	 * Return for t or f - checkbox values
	 *
	 * @param s (String):  the String
	 * @return String
	 */
	public static String getTagValDisplay(String s, boolean okShowAll)
	{
		String ret = "";

		Vector<String> exp = explode(s, "^^^");
		for (int i = 0; i < exp.size(); i++)
		{
			String thisOne = backToAll((String) exp.get(i));

			String thisField = getField(thisOne, "~~~", 1);
			String thisValue = getField(thisOne, "~~~", 2);

			if (thisField.startsWith("Transfer: Password"))
				thisValue = "***************";
			else if (thisField.startsWith("Transfer:") && !okShowAll)
				thisValue = "***************";
			else if (thisValue.length()>50)
				thisValue = thisValue.substring(0, 45) + " ... ";

			if (ret.equals(""))
				ret = thisField + " = " + thisValue;
			else
				ret += "<br>" + thisField + " = " + thisValue;

		}

		return ret;
	} // end getTagValDisplay

	// utility functions on vectors, strings, boolean, etc..

	public static String getValFromAreaSettingsVector(Vector all, String id, String field)
	{

		String ret = "";

		for (int i = 0; i < all.size(); i++)
		{
			AreaSettings thisOne = (AreaSettings)all.get(i);
			if (thisOne.id.equals(id)) {
				if (field.equals("name"))
					ret = thisOne.name;
				else if (field.equals("cc_allactivity"))
					ret = thisOne.cc_allactivity;
				else if (field.equals("passcode_on_register"))
					ret = thisOne.passcode_on_register;
				else if (field.equals("max_concurrent_runs"))
					ret = thisOne.max_concurrent_runs;
				else if (field.equals("max_products"))
					ret = thisOne.max_products;
				else if (field.equals("currencysymbol"))
					ret = thisOne.currencysymbol;
				else if (field.equals("time_interval_choices"))
					ret = thisOne.time_interval_choices;
				else if (field.equals("time_interval_default_choice"))
					ret = thisOne.time_interval_default_choice;
				else if (field.equals("class_ids_for_roles_of_users"))
					ret = thisOne.class_ids_for_roles_of_users;
				else if (field.equals("default_currency"))
					ret = thisOne.default_currency;
				else if (field.equals("pricing_rule_choices_override"))
					ret = thisOne.pricing_rule_choices_override;
				else if (field.equals("id"))
					ret = thisOne.id;
				else if (field.equals("thresholdpercent"))
					ret = thisOne.thresholdpercent;

				break;
			}
		}

		return ret;
	}


	public static Vector<String> getMatching(Vector<Vector<String>> all, String matchText, int matchIndex)
	{
		for (int i = 0; i < all.size(); i++)
		{
			Vector<String> thisOne = all.get(i);
			if (thisOne.get(matchIndex).equals(matchText))
			{
				return thisOne;
			}
		}

		return null;
	}

	public static String getMatchingAll_ReturnIndexVal(Vector<Vector<String>> all, String matchText, int matchIndex, int returnIndex)
	{
		String ret = "";
		for (int i = 0; i < all.size(); i++)
		{
			Vector<String> thisOne = all.get(i);
			if (thisOne.size()>=matchIndex && thisOne.get(matchIndex).equals(matchText))
			{
				ret = thisOne.get(returnIndex);
			}
		}

		return ret;
	}

	public static String getMatchingAll_ReturnIndexValDefaultReturn(Vector<Vector<String>> all, String matchText, int matchIndex, int returnIndex, String defaultReturnValue)
	{
		String ret = "";
		for (int i = 0; i < all.size(); i++)
		{
			Vector<String> thisOne = all.get(i);
			if (thisOne.size()>=matchIndex && thisOne.get(matchIndex).equals(matchText))
			{
				ret = thisOne.get(returnIndex);
				break;
			}
		}

		if (ret.equals(""))
			ret = defaultReturnValue;

		return ret;
	}

	public static String getMatchingAll_ReturnIndexVal(Vector<Vector<String>> all, String matchText, String matchText2, int matchIndex, int matchIndex2, int returnIndex)
	{
		String ret = "";
		for (int i = 0; i < all.size(); i++)
		{
			Vector<String> thisOne = all.get(i);
			if (thisOne.get(matchIndex).equals(matchText) && thisOne.get(matchIndex2).equals(matchText2))
			{
				ret = thisOne.get(returnIndex);
				break;
			}
		}

		return ret;
	}

	public static String getMatchingAll_ReturnIndexVal(Vector<Vector<String>> all, String matchText, String matchText2, String matchText3, int matchIndex, int matchIndex2, int matchIndex3, int returnIndex)
	{
		String ret = "";
		for (int i = 0; i < all.size(); i++)
		{
			Vector<String> thisOne = all.get(i);
			if (thisOne.get(matchIndex).equals(matchText) && thisOne.get(matchIndex2).equals(matchText2) && thisOne.get(matchIndex3).equals(matchText3))
			{
				ret = thisOne.get(returnIndex);
				break;
			}
		}

		return ret;
	}

	public static String getMatchingAll_ReturnIndexVal(Vector<Vector<String>> all, String matchText, String matchText2, String matchText3, String matchText4, int matchIndex, int matchIndex2, int matchIndex3, int matchIndex4, int returnIndex)
	{
		String ret = "";
		for (int i = 0; i < all.size(); i++)
		{
			Vector<String> thisOne = all.get(i);
			if (thisOne.get(matchIndex).equals(matchText) && thisOne.get(matchIndex2).equals(matchText2) && thisOne.get(matchIndex3).equals(matchText3) && thisOne.get(matchIndex4).equals(matchText4))
			{
				ret = thisOne.get(returnIndex);
				break;
			}
		}

		return ret;
	}

	public static Vector<String>  getMatchingAll_ReturnVector(Vector<Vector<String>> all, String matchText, int matchIndex)
	{
		Vector<String>  ret = new Vector<String>();
		for (int i = 0; i < all.size(); i++)
		{
			Vector<String> thisOne = all.get(i);
			if (thisOne.get(matchIndex).equals(matchText))
			{
				ret = thisOne;
				break;
			}
		}

		return ret;
	}

	public static Vector<String>  getMatchingAll_ReturnVector(Vector<Vector<String>> all, String matchText, String matchText2, int matchIndex, int matchIndex2)
	{
		Vector<String>  ret = new Vector<String>();
		for (int i = 0; i < all.size(); i++)
		{
			Vector<String> thisOne = all.get(i);
			if (thisOne.get(matchIndex).equals(matchText) && thisOne.get(matchIndex2).equals(matchText2))
			{
				ret = thisOne;
				break;
			}
		}

		return ret;
	}

	public static Vector<String>  getMatchingAll_ReturnVector(Vector<Vector<String>> all, String matchText, String matchText2, String matchText3, int matchIndex, int matchIndex2, int matchIndex3)
	{
		Vector<String>  ret = new Vector<String>();
		for (int i = 0; i < all.size(); i++)
		{
			Vector<String> thisOne = all.get(i);
			if (thisOne.get(matchIndex).equals(matchText) && thisOne.get(matchIndex2).equals(matchText2) && thisOne.get(matchIndex3).equals(matchText3))
			{
				ret = thisOne;
				break;
			}
		}

		return ret;
	}

	public static Vector<Vector<String>> getMatchingAll(Vector<Vector<String>> all, String matchText, int matchIndex)
	{
		Vector<Vector<String>> ret = new Vector<Vector<String>>();
		for (int i = 0; i < all.size(); i++)
		{
			Vector<String> thisOne = all.get(i);
			if (thisOne.get(matchIndex).equals(matchText))
			{
				ret.add(thisOne);
			}
		}

		return ret;
	}

	public static String nullToDefault(String s, String defaultValue)
	{
		return s == null ? defaultValue : s.trim();   // should always trim these web form inputs.. avoid trouble later (leading and trailing spaces.. due to copy / paste to web text field)
	}

	public static String nullToDefaultAndHTMLEscape(String s, String defaultValue)
	{
		return s == null ? HtmlUtils.htmlEscape(defaultValue) : HtmlUtils.htmlEscape(s.trim());   // should always trim these web form inputs.. avoid trouble later (leading and trailing spaces.. due to copy / paste to web text field)
	}

	public static String stringEmptyToNull(String s)
	{
		if (s.equals(""))
			return "null";
		else
			return s;
	}
	
	public static String toTFFromBoolean(boolean s)
	{
		if (s)
			return "t";
		else
			return "f";
	}	

	public static String toYBlankFromTF(String s)
	{
		String ret= "";
		if (s.equals("t") || s.equals("T"))
			ret = "Yes";
		return ret;
	}

	public static Vector getVectorForItems (String... args) {
		Vector ret = new Vector();
	    for (String arg : args) {
			ret.add(arg);
	    }
	    return ret;
	}

	/**
	 * Prepares datePrint for file
	 *
	 * @param now (String): SQL time
	 * @param SESSdatecontrolformat (String):  Date Format
	 * @param timezoneinfo (String):  sess.timezoneinfo
	 * @return String -  the altered string
	 */
	public static String dateForFile(String now, String SESSdatecontrolformat, String timezoneinfo)
	{

		datehelp myDate = new datehelp();

		String createdPrint = myDate.getShortDateTime_TZ(now, SESSdatecontrolformat, timezoneinfo);
		
		createdPrint = replaceAll(replaceAll(createdPrint, " ", "_"), ":", "_");
		
		if (createdPrint == null || createdPrint.equals(""))
			return createdPrint;

		return createdPrint;
	}

}
