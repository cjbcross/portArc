package ssoext;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.Key;
import java.security.Provider;
import java.security.Security;
import java.util.StringTokenizer;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class cryptohelp {
    // private static final String KEY_STRING_MAIN = "34-59-69-43-87-3-217-30-15-16-43-64-75-25-14-12";
    // private static final String KEY_STRING_MAIN_4 = "29-55-67-41-84-4-213-28-11-18-47-65-75-29-14-14";
    // private static final String IV_STRING_MAIN_4 = "4-12-52-2-9-2-18-4-37-5-74-88-19-3-22-20";

    public cryptohelp() {
    }

    public static void main(String[] var0) {
        String var1 = var0[0];
        String var2 = var0[1];
        String pin = getPIN();
        String var3 = "";
        String var4 = "padding~~~~pkey=" + var1 + "&PIN=" + pin + "~~~~padding";

        try {
            initBouncyCastle();
            Cipher var5 = Cipher.getInstance("AES/GCM/NoPadding", "BC");
            var5.init(1, getKeyMain4(), getKeyMainIV4());
            var3 = getString(var5.doFinal(var4.getBytes()));
        } catch (Exception var7) {
            ;
        }

        try {
            PrintWriter var8 = new PrintWriter(var2 + "/" + "pkey.txt", "UTF-8");
            var8.println("gz=" + var3);
            var8.close();
        } catch (IOException var6) {
            ;
        }

    }

    private static String getString(byte[] var0) {
        StringBuffer var1 = new StringBuffer();

        for (int var2 = 0; var2 < var0.length; ++var2) {
            byte var3 = var0[var2];
            var1.append(255 & var3);
            if (var2 + 1 < var0.length) {
                var1.append("-");
            }
        }

        return var1.toString();
    }

    private static byte[] getBytes(String var0) {
        ByteArrayOutputStream var1 = new ByteArrayOutputStream();
        StringTokenizer var2 = new StringTokenizer(var0, "-", false);

        while (var2.hasMoreTokens()) {
            int var3 = Integer.parseInt(var2.nextToken());
            var1.write((byte) var3);
        }

        return var1.toByteArray();
    }

    private static Key getKeyMain4() {
        try {
            byte[] var0 = getBytes("29-55-67-41-84-4-213-28-11-18-47-65-75-29-14-14");
            SecretKeySpec var1 = new SecretKeySpec(var0, "AES");
            return var1;
        } catch (Exception var2) {
            return null;
        }
    }

    private static IvParameterSpec getKeyMainIV4() {
        try {
            byte[] var0 = getBytes("4-12-52-2-9-2-18-4-37-5-74-88-19-3-22-20");
            IvParameterSpec var1 = new IvParameterSpec(var0);
            return var1;
        } catch (Exception var2) {
            return null;
        }
    }

    private static String initBouncyCastle() {
        String var0 = "";
        Provider[] var1 = Security.getProviders();
        boolean var2 = false;

        for (int var3 = 0; var3 < var1.length; ++var3) {
            String var4 = var1[var3].toString();
            if (var4.indexOf("BC version") > -1) {
                var2 = true;
            }
        }

        if (!var2) {
            BouncyCastleProvider var5 = new BouncyCastleProvider();
            Security.addProvider(var5);
        }

        return var0;
    }

    public static String decrypt4( String source ) {
    	try
    	{
			initBouncyCastle();

      		// Get our secret key
      		Key key = getKeyMain4();
      		IvParameterSpec keyiv = getKeyMainIV4();

      		// Create the cipher
      		Cipher aesCipher =
			Cipher.getInstance("AES/GCM/NoPadding", "BC");
			//Cipher.getInstance("AES/CBC/PKCS5Padding");

      		// Encrypt the cleartext
      		byte[] ciphertext = getBytes( source );

      		// Initialize the same cipher for decryption
      		aesCipher.init(Cipher.DECRYPT_MODE, key, keyiv);

      		// Decrypt the ciphertext
      		byte[] cleartext = aesCipher.doFinal(ciphertext);

      		// Return the clear text
      		return new String( cleartext );
    	}
    	catch( Exception e )
    	{
            //e.printStackTrace();
    	}
    	return null;
	}

    private static String getPIN() {
        SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
        TimeZone timeZone = TimeZone.getTimeZone("US/Eastern");
        sdf.setTimeZone(timeZone);
        Date date = new Date();
        String time = sdf.format(date);

        return time;
    }

}
