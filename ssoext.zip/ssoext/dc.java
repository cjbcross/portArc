package ssoext;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.Key;
import java.security.Provider;
import java.security.Security;
import java.util.StringTokenizer;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.Vector;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import ssoext.texthelp;
import ssoext.cryptohelp;

public class dc {
    public static void main(String[] var0) {

        String pkey = "";
        String pin = "";

        String tdPin = getPIN();
        // String gzPass = texthelp.nullToDefault ((String)request.getParameter ("gz"), "");
        String gzPass = texthelp.nullToDefault ("47-5-148-230-250-122-202-38-96-220-235-8-45-156-180-210-88-176-240-152-182-159-53-153-117-139-112-156-203-240-103-14-120-133-130-22-155-229-154-232-238-159-218-109-37-200-95-217-89-231-168-223-176-243-240-168-255-159-165-42-233-225", "");
        System.out.println(gzPass);
        if (!gzPass.equals("")) {

            String gzPassUnEncrypted = cryptohelp.decrypt4 (gzPass);
            if (gzPassUnEncrypted != null) {

                gzPassUnEncrypted = texthelp.getField (gzPassUnEncrypted, "~~~~", 2);

                Vector splitGZ = texthelp.explode (gzPassUnEncrypted, "&");
                for (int i=0; i< splitGZ.size(); i++) {
                    String thisSplitGZ = (String)splitGZ.get(i);
                    String key = texthelp.getField (thisSplitGZ, "=", 1);
                    if (key.equals("pkey")) {
                        pkey = texthelp.getField (thisSplitGZ, "=", 2);
                        System.out.println(pkey);
                    }
                    else if (key.equals("PIN")) {
                        pin = texthelp.getField (thisSplitGZ, "=", 2);
                        System.out.println(pin);
                        if(pin.equals(tdPin))
                            System.out.println("They Match!");
                    }
                }
            }
        }
    }

    private static String getPIN() {
        SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
        TimeZone timeZone = TimeZone.getTimeZone("US/Eastern");
        sdf.setTimeZone(timeZone);
        Date date = new Date();
        String time = sdf.format(date);

        return time;
    }
}